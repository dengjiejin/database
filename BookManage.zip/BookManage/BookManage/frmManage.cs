﻿using BookManage.BLL;
using BookManage.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookManage
{
    public partial class frmManage : Form
    {
        private Reader reader = new Reader();
        private ReaderAdmin readerBLL = new ReaderAdmin();
        public frmManage()
        {
            InitializeComponent();
            
        }

        private void frmManage_Load(object sender, EventArgs e)//数据绑定
        {
            DateBind();
        }

        private void DateBind()
        {
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select rdID 读者编号,rdName 读者姓名,rdSex 性别,rdType 读者类别,rdAdminRoles 读者角色 from TB_Reader", conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            txtrdID.Text = dataGridView1[0, 0].Value.ToString();
            txtrdName.Text = dataGridView1[1, 0].Value.ToString();
            txtrdSex.Text = dataGridView1[2, 0].Value.ToString();
            cmbrdType.Text = dataGridView1[3, 0].Value.ToString();
            cmbrdAdminroles.Text = dataGridView1[4, 0].Value.ToString();
        }

        private void setReaderToText(int rowindex)
        {
            txtrdID.Text = dataGridView1[0, rowindex].Value.ToString();
            txtrdName.Text = dataGridView1[1, rowindex].Value.ToString();
            txtrdSex.Text = dataGridView1[2, rowindex].Value.ToString();
            cmbrdType.Text = dataGridView1[3, rowindex].Value.ToString();
            cmbrdAdminroles.Text = dataGridView1[4, rowindex].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)//更改
        {
            //int rowindex = dataGridView1.CurrentCell.RowIndex;
            //setReaderToText(rowindex);
            reader.rdID = Convert.ToInt32(txtrdID.Text);
            reader.rdType =Convert.ToInt32(cmbrdType.Text);
            reader.rdAdminRoles =Convert.ToInt32(cmbrdAdminroles.Text);
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "update TB_reader set rdType=@rdType,rdAdminRoles=@rdAdminRoles where rdID=@rdID";
            cmd.Parameters.AddWithValue("@rdID", reader.rdID);
            cmd.Parameters.AddWithValue("@rdType", reader.rdType);
            cmd.Parameters.AddWithValue("@rdAdminRoles", reader.rdAdminRoles);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("更改成功！", "提示",MessageBoxButtons.OK);
            }
            catch (SqlException ex)
            {
                MessageBox.Show("更改失败！","提示",MessageBoxButtons.OK);
            }
            cmd.ExecuteNonQuery();
            DateBind();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            /*************点击第一行未解决******************/
            int rowindex = dataGridView1.CurrentCell.RowIndex;
            setReaderToText(rowindex);
        }

        private void button2_Click(object sender, EventArgs e)//返回
        {
            this.Close();
        }
    }
}

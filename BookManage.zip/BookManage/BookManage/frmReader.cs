﻿using BookManage.BLL;
using BookManage.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookManage
{
    internal enum opStatus
    {
        inSelect = 0,//查询操作状态
        inNew = 1,//办理新借书证状态
        inChange = 2//变更借书证状态
    };
    public partial class frmReader : Form
    {
        private DataTable dt=null;
        private Reader reader = new Reader();
        private ReaderAdmin readerBLL=new ReaderAdmin();
        private opStatus ops;
        public frmReader()
        {
            InitializeComponent();
            //Reader reader = frmLogin.reader;
            dt = readerBLL.GetAllReaderType();
            foreach(DataRow dr in dt.Rows)
            {
                //cmbTypeForQry.Items.Add(dr["rdType"].ToString() + "--" + dr["rdTypeName"].ToString());
                //cmbType.Ttems.Add(dr["rdType"].ToString() + "--" + dr["rdTypeName"].ToString());
            }
            SetStatus(opStatus.inSelect);
            dt = readerBLL.GetReader(0, "", "");
            ShowData();
            //SetReaderToText();
        }
        private void ShowData() {
            dgvReader.DataSource = dt;
            //dgvReader.Columns["rdID"].HeaderText = "借书证号";
            //dgvReader.Columns["rdName"].HeaderText = "姓名";
            //dgvReader.Columns["rdID"].HeaderText = Reader.ColumTitle("rdID");
            //dgvReader.Columns["rdName"].HeaderText = Reader.ColumTitle("rdName");
            foreach(DataColumn dc in dt.Columns)
            {
                dgvReader.Columns[dc.ColumnName].HeaderText = Reader.ColumnTitle(dc.ColumnName);
            }
        }


        private void SetReaderToText()
        {
            txtID.Text = Convert.ToString(reader.rdID);
            txtName.Text = reader.rdName;
            txtPwd.Text = reader.rdPwd;
            cmbSex.Text = reader.rdSex;
            //cmbType.Text = Convert.ToString(reader.rdType);
            if (reader.rdType == 10)
            {
                cmbType.Text = "教师";
            }else if (reader.rdType == 20)
            {
                cmbType.Text = "本科生";
            }else if (reader.rdType == 21)
            {
                cmbType.Text = "专科生";
            }else if (reader.rdType==30)
            {
                cmbType.Text = "硕士研究生";
            }else if (reader.rdType==31)
            {
                cmbType.Text = "博士研究生";
            }
            cmbDept.Text = reader.rdDept;
            txtPhone.Text = reader.rdPhone;
            txtEmail.Text = reader.rdEmail;
            dtpDateReg.Text = reader.rdDateReg.ToString();//*****
            if (reader.rdPhoto == null)
                picboxPhoto.Image = null;
            else
            {
                MemoryStream ms = new MemoryStream(reader.rdPhoto);
                Image imgPhoto = Bitmap.FromStream(ms, true);
                picboxPhoto.Image = imgPhoto;

            }
            txtStatus.Text = reader.rdStatus;
            txtBorrowQty.Text = Convert.ToString(reader.rdBorrowQty);
            txtAdminRoles.Text = Convert.ToString(reader.rdAdminRoles);
        }
        private void SetTextToReader()
        {
            /*****************************************/
            //reader.rdID =Convert.ToInt32(txtID.Text);
            reader.rdName = txtName.Text;
            reader.rdPwd = txtPwd.Text;
            reader.rdSex = cmbSex.Text;
            int i = cmbType.Text.IndexOf("--");
            if (i > 0)
                reader.rdType = Convert.ToInt32(cmbType.Text.Substring(0, i));
            else { 
                //reader.rdType = Convert.ToInt32(cmbType.Text);
                if (cmbType.Text == "教师")
                {
                    reader.rdType = 10;
                }else if (cmbType.Text == "本科生")
                {
                    reader.rdType = 20;
                }else if (cmbType.Text == "专科生")
                {
                    reader.rdType = 21;
                }else if (cmbType.Text == "硕士研究生")
                {
                    reader.rdType = 30;
                }else if (cmbType.Text=="博士研究生")
                {
                    reader.rdType = 31;
                }
            }
            reader.rdDept = cmbDept.Text;
            reader.rdPhone = txtPhone.Text;
            reader.rdEmail = txtEmail.Text;
            reader.rdDateReg = Convert.ToDateTime(dtpDateReg.Text);/*************/
            if (picboxPhoto.Image != null)
            {
                MemoryStream ms = new MemoryStream();
                picboxPhoto.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
                reader.rdPhoto = ms.GetBuffer();
            }

            reader.rdStatus = txtStatus.Text;
            reader.rdDateReg = DateTime.Now;
            reader.rdBorrowQty = Convert.ToInt32(txtBorrowQty.Text);
            reader.rdAdminRoles = Convert.ToInt32(txtAdminRoles.Text);
        }

        private void SetStatus(opStatus opst) {
            ops = opst;
            switch (ops)
            {
                case opStatus.inSelect:
                    toolStrip1.Enabled = true;//查询工具栏
                    groupBox1.Enabled = true;//查询结果
                    groupBox2.Enabled = false;//读者信息
                    break;
                case opStatus.inNew:
                    toolStrip1.Enabled = false;
                    groupBox1.Enabled = false;
                    groupBox2.Enabled = true;
                    btnAddReader.Enabled = true;
                    btnUpdateReader.Enabled = false;
                    break;
                case opStatus.inChange:
                    toolStrip1.Enabled = false;
                    groupBox1.Enabled = false;
                    groupBox2.Enabled = true;
                    btnAddReader.Enabled = false;
                    btnUpdateReader.Enabled = true;
                    break;
            }
        }

        private void btnNewDoc_Click(object sender, EventArgs e)//办理借书证
        {
            if (txtNameForQry.Text == "" && cmbDeptForQry.Text == "" && cmbTypeForQry.Text == "")
            {
                MessageBox.Show("请先确认读者是否存在", "提示");
                return;
            }
            if (dgvReader[0, 0].Value != null) {
                MessageBox.Show("该读者可能已经存在！请确认");
                return;
            }
                
       
            SetStatus(opStatus.inNew);
            txtID.Text = "";
            txtName.Text = "";
            txtPwd.Text = "";
            cmbSex.Text = "";
            txtBorrowQty.Text = "";
            txtStatus.Text = "";
            txtAdminRoles.Text = "";
            cmbType.Text = "";
            cmbDept.Text = "";
            txtPhone.Text = "";
            txtEmail.Text = "";
            dtpDateReg.Text = "";
            picboxPhoto.Image = null;
            //SetTextToReader();

        }

        private void btnChangeDoc_Click(object sender, EventArgs e)//变更借书证
        {
            txtPwd.Enabled = false;
            SetStatus(opStatus.inChange);
        }

        private void btnCancelChange_Click(object sender, EventArgs e)
        {
            SetStatus(opStatus.inSelect);
        }

        private void btnQuery_Click(object sender, EventArgs e)//查询
        {
            int rdType;
            string rdDept, rdName;

            if (cmbTypeForQry.Text.Trim() == "")
                rdType = 0;
            else
            {
                int i = cmbTypeForQry.Text.IndexOf("--");
                if (i > 0)
                    rdType = Convert.ToInt32(cmbTypeForQry.Text.Substring(0, i));
                else
                    rdType = Convert.ToInt32(cmbTypeForQry.Text);
            }
            rdDept = cmbDeptForQry.Text;
            rdName = txtNameForQry.Text;
            dt = readerBLL.GetReader(rdType, rdDept, rdName);
            ShowData();
        }

        private void btnToExcel_Click(object sender, EventArgs e)//导出ExceL
        {
            ExcelHelper.ExportToExcel(dt);
        }

        private void dgvReader_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvReader.CurrentCell == null)
                return;

            /**************************************************/
            //// reader = readerBLL.GetReader((int)(dgvReader["rdID", dgvReader.C.urrentCell.RowIndex].Value));
            if (dgvReader[1, 0].Value.ToString() == "")
                return;
            if (dgvReader[dgvReader.CurrentCell.RowIndex, 0].Value.ToString() == "")
                return;

            //reader = readerBLL.GetReader(Convert.ToInt32(dgvReader["rdID", dgvReader.CurrentCell.RowIndex].Value));
            int id = Convert.ToInt32(dgvReader[0, dgvReader.CurrentCell.RowIndex].Value);
            reader = readerBLL.GetReader(id);
            //reader.rdPhoto = Serialize(dgvReader[8, dgvReader.CurrentCell.RowIndex].Value);
            SetReaderToText();
        }

        private void btnAddReader_Click(object sender, EventArgs e)//确认办证
        {
            //if(IsN)
            //if(dgvReader[0,0].Value!=null)
            if ( txtName.Text == "" || txtPhone.Text == "" || txtEmail.Text == "" || cmbDept.Text == "" || cmbSex.Text == "" || cmbType.Text == "" || dtpDateReg.Text == "")
            {
                MessageBox.Show("请完整填写信息！");
                return;
            }
                txtBorrowQty.Text = "0";
            txtAdminRoles.Text = "0";
            SetTextToReader();
            Random rnd = new Random();

            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            do
            {
                reader.rdID = rnd.Next(10000);
                cmd.CommandText = "select * from TB_Reader where rdID=@rdID";
                cmd.Parameters.AddWithValue("@rdID", reader.rdID);
            } while (cmd.ExecuteNonQuery() == 0);
            reader.rdStatus = "有效";
            //reader.rdBorrowQty = 0;
            //reader.rdAdminRoles = 0;
            try
            {
                readerBLL.Add(reader);
                MessageBox.Show("办理成功！"+"\n"+"借书证号为"+reader.rdID);
            }
            catch (SqlException ex)
            {
                MessageBox.Show("办理失败！");
            }
            
        }

        private void btnUpdateReader_Click(object sender, EventArgs e)//确认变更
        {
           
            SetTextToReader();
            try
            {
                readerBLL.Update(reader);
                MessageBox.Show("变更成功！");
            }
            catch (SqlException ex) {
                MessageBox.Show("变更失败！");
            }

        }

        private void btnLoadPictureFile_Click(object sender, EventArgs e)//打开图片
        {
            OpenFileDialog ofd1 = new OpenFileDialog();
            ofd1.Filter = "图片文件(*.jpg;*.bmp;*.png;*.gif)|*.jpg;*.bmp;*.png;*.gif";
            if (ofd1.ShowDialog()==DialogResult.OK) {
                Image imgPhoto = Image.FromFile(ofd1.FileName);
                picboxPhoto.Image = imgPhoto;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)//撤销
        {
            this.Close();
        }

        private void btnCancelDoc_Click(object sender, EventArgs e)//注销
        {
            reader.rdID = Convert.ToInt32(dt.Rows[0][0]);
            reader.rdName = dt.Rows[0][1].ToString();
            reader.rdSex = dt.Rows[0][2].ToString();
            reader.rdType = Convert.ToInt32(dt.Rows[0][3]);
            reader.rdDept = dt.Rows[0][4].ToString();
            reader.rdPhone = dt.Rows[0][5].ToString();
            reader.rdEmail = dt.Rows[0][6].ToString();
            reader.rdDateReg = Convert.ToDateTime(dt.Rows[0][7].ToString());
            reader.rdPhoto = null;
            reader.rdStatus = dt.Rows[0][9].ToString();
            reader.rdBorrowQty = Convert.ToInt32(dt.Rows[0][10].ToString());
            reader.rdPwd = dt.Rows[0][11].ToString();
            reader.rdAdminRoles = Convert.ToInt32(dt.Rows[0][12].ToString());
            if (reader.rdBorrowQty > 0) {
                MessageBox.Show("请先归还所借的书籍！");
            }else
            {
                try
                {
                    readerBLL.Delete(reader);
                    MessageBox.Show("注销成功！");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("注销失败！");
                }

            }
            
        }

        private void btnLossDoc_Click(object sender, EventArgs e)//挂失
        {
            int rowindex= dgvReader.CurrentCell.RowIndex;
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "update TB_reader set rdStatus='挂失' where rdID=" + Convert.ToInt32(dgvReader[0, rowindex].Value);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("挂失成功！");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("挂失失败！");
            }

            
        }

        private void btnUnlossDoc_Click(object sender, EventArgs e)//解除挂失
        {
            int rowindex = dgvReader.CurrentCell.RowIndex;
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "update TB_reader set rdStatus='有效' where rdID=" + Convert.ToInt32(dgvReader[0, rowindex].Value);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("解除挂失成功！");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("解除挂失失败！");
            }
        }

        private void txtPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsNumber(e.KeyChar)) && e.KeyChar != (Char)8)
            {
                e.Handled = true;
            }else
            {
                //MessageBox.Show("请输入数字！");
            }
        }

        private void txtPhone_MouseClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("只可输入11位数字！");
        }

        private void txtEmail_KeyPress(object sender, KeyPressEventArgs e)
        {
         
        }

        //private void txtEmail_MouseLeave(object sender, EventArgs e)
        //{
        //    if (!txtEmail.Text.Contains("@"))
        //    {
        //        MessageBox.Show("格式不正确");
        //        return;
        //    }
        //}
    }
}

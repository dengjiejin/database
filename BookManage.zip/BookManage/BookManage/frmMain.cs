﻿using BookManage.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookManage
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
            InitMenu();
        }
        public void InitMenu() {
            Reader reader = frmLogin.reader;
            //图书管理ToolStripMenuItem.Visible=true;//是否可见
            //图书管理ToolStripMenuItem.AVaillble = false;//是否活动
            图书管理ToolStripMenuItem.Enabled = reader.IsBookAdmin();
            读者管理ToolStripMenuItem.Enabled = (reader.IsReaderAdmin() || reader.IsSystemAdmin());
            借阅管理ToolStripMenuItem.Enabled = reader.IsBorrowAdmin();
            权限管理ToolStripMenuItem.Enabled = reader.IsSystemAdmin();

            tssUser.Text = "登陆用户：" + reader.rdName + "|" + reader.rdDept;
        }

        private void 办理借书证ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Application.Run(new frmReader());

            frmReader reader = new frmReader();
            reader.ShowDialog();

        }

        private void 密码修改ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUpdatePwd reader = new frmUpdatePwd();
            reader.ShowDialog();
        }

        private void 读者类型管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReaderType readertype = new frmReaderType();
            readertype.ShowDialog();
        }

        private void 新书入库ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAddBook addbook = new frmAddBook();
            addbook.ShowDialog();
        }

        private void 图书信息维护ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBook book = new frmBook();
            book.ShowDialog();
        }

        private void 借书ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBorrowBook borrowbook = new frmBorrowBook();
            borrowbook.ShowDialog(); 
        }

        private void 权限管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmManage manage = new frmManage();
            manage.ShowDialog();

        }

        //private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        //{

        //}
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BookManage.Model;
using BookManage.BLL;

namespace BookManage
{
    public partial class frmBook : Form
    {
        public static int flag = 0;
        public static  Book book = new Book();
        private BookAdmin BookBLL = new BookAdmin();
        private DataTable dt = null;
        public frmBook()
        {
            InitializeComponent();
        }

        //private void frmBook_Load(object sender, EventArgs e)
        //{
        //    DataBind();
        //}
        private void ShowData()
        {
            dataGridView1.DataSource = dt;
            foreach (DataColumn dc in dt.Columns)
            {
                dataGridView1.Columns[dc.ColumnName].HeaderText = Book.ColumnTitle(dc.ColumnName);
            }
        }
        private void setTextToBook()
        {
            book.bkID =Convert.ToInt32(txtbkID.Text);
            book.bkCode = txtbkCode.Text;
            book.bkName = txtbkName.Text;
            book.bkAuthor = txtbkAuthor.Text;
            book.bkPress = txtbkPress.Text;
            book.bkDatePress = Convert.ToDateTime(txtbkPressDate.Text);
            book.bkDateIn = Convert.ToDateTime(txtDateIn.Text);
        }

        private void DataBind()//数据绑定
        {
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select bkID 图书序号,bkCode 图书编号,bkName 图书名,bkAuthor 图书作者,bkPress 出版社,bkDatePress 出版日期,bkISBN ISBN书号,bkCatalog 分类号,bkLanguage 语言,bkPages 页数,bkPrice 价格,bkDateIn 入馆日期,bkStatus 图书状态 from TB_Book", conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void toolStripButton9_Click(object sender, EventArgs e)//返回
        {
            this.Close();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)//添加
        {
            frmAddBook addbook =new frmAddBook();
            addbook.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)//浏览
        {
            DataBind();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)//删除
        {
            DialogResult dr = MessageBox.Show("确认删除！", "提示", MessageBoxButtons.YesNo);
            if (dr == DialogResult.No) {
                return;
            }
            if (dataGridView1.DataSource == null)
                return;
            int rowindex = dataGridView1.CurrentCell.RowIndex;
            book.bkID = Convert.ToInt32(dataGridView1[0, rowindex].Value);
            try
            {
                BookBLL.Delete(book);
                DataBind();
            MessageBox.Show("删除成功！");
        }
            catch (Exception ex)
            {
                MessageBox.Show("删除失败！\n该书处于借出状态");
            }

}

        private void button1_Click(object sender, EventArgs e)//查询
        {
            
            int bkID,number=0;
            string bkCode, bkName, bkAuthor, bkPress;
            DateTime bkPressDate, bkDateIN;
            bkCode = txtbkCode.Text;
            //if()
            bkName = txtbkName.Text;
            bkPress = txtbkPress.Text;
            bkAuthor = txtbkAuthor.Text;
            if (txtbkID.Text.Trim() == "") {
                bkID = 0;
            }
            else
            {
                for (int i = 0; i < txtbkID.Text.Length; i++) {
                    if (!char.IsNumber(txtbkID.Text[i]))
                    {
                        MessageBox.Show("图书序号为非法输入\n请输入数字！");
                        return;
                    }
                }
                bkID = Convert.ToInt32(txtbkID.Text);
            }
          
            if (txtbkPressDate.Text.Trim() == "")
            {
                // bkPressDate = Convert.ToDateTime("0-0-0");
            }
            else { bkPressDate = Convert.ToDateTime(txtbkPressDate.Text); }
            if (txtDateIn.Text.Trim() == "")
            {
                Nullable<DateTime> DateTimeIsNull = null;
                //DateTime dtime;

                //bkDateIN = DateTimeIsNull.Value;
                //bkDateIN = .value;
            }
            else
            {
                bkDateIN = Convert.ToDateTime(txtDateIn.Text);
            }
            DataTable dt = BookBLL.GetBookPlus(bkID, bkCode, bkName, bkAuthor, bkPress/*, bkPressDate, bkDateIN*/);
            //ShowData();
            dataGridView1.DataSource = dt;

        }

        private void toolStripButton8_Click(object sender, EventArgs e)//预览
        {
            if (dataGridView1.DataSource == null)
                return;
        }

        private void toolStripButton7_Click(object sender, EventArgs e)//导出Excel
        {
            if (dataGridView1.DataSource == null)
                return;
            ExcelHelper.ExportToExcel(dt);
        }

        private void toolStripButton5_Click(object sender, EventArgs e)//修改
        {
            flag = 0;
            if (dataGridView1.DataSource == null)
                return;
            int rowindex = dataGridView1.CurrentCell.RowIndex;
            int bkid = Convert.ToInt32(dataGridView1[0, rowindex].Value);
            book = BookBLL.GetBook(bkid);
            frmBookDetail bookdetail = new frmBookDetail();
            bookdetail.ShowDialog();
            DataBind();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)//明细
        {
            /***如何设置只读**/
            flag = 1;
            if (dataGridView1.DataSource == null)
                return;
            int rowindex = dataGridView1.CurrentCell.RowIndex;

            int bkid = Convert.ToInt32(dataGridView1[0, rowindex].Value);
            book = BookBLL.GetBook(bkid);
            frmBookDetail frmdetail = new frmBookDetail();
            frmdetail.ShowDialog();
            //frmdetail.Enabled = false;
        }

        private void toolStripButton3_Click(object sender, EventArgs e)//高级查询
        {

        }
    }
}

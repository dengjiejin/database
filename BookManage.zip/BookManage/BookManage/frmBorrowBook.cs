﻿using BookManage.BLL;
using BookManage.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookManage
{
    public partial class frmBorrowBook : Form
    {
        private Reader reader = new Reader();
        private Book book = new Book();
        private Borrow borrow = new Borrow();
        private ReaderType readertype = new ReaderType();
        private ReaderAdmin readerBLL = new ReaderAdmin();
        private BookAdmin bookBLL = new BookAdmin();
        private BorrowAdmin borrowBLL = new BorrowAdmin();
        private ReaderTypeAdmin readertypeBLL = new ReaderTypeAdmin();
        private Reader OperatorUser = frmLogin.reader;
        public frmBorrowBook()
        {
            InitializeComponent();
            label11.Text = "操作员：" + OperatorUser.rdName;
            label12.Text = DateTime.Now.ToString();
        }
        private void SetReaderToText()
        {
            txtrdName.Text = reader.rdName.ToString();
            txtrdDept.Text = reader.rdDept.ToString();
            txtrdType.Text =reader.rdType.ToString();
            txtBorrowNum.Text = reader.rdBorrowQty.ToString();
            txtBorrowDay.Text = readertype.CanLendDay.ToString();
            txtBorrowQty.Text = readertype.CanLendQty.ToString();
        }

        private void button1_Click(object sender, EventArgs e)//读者编号查询
        {
            
            if (txtrdID.Text == "")
            {
                MessageBox.Show("请填写读者信息！");
                return;
            }
                
            for (int i = 0; i < txtrdID.Text.Length; i++)
            {
                if (!char.IsNumber(txtrdID.Text[i]))
                {
                    MessageBox.Show("读者为非法输入\n请输入数字！");
                    return;
                }
            }
            int ID = Convert.ToInt32(txtrdID.Text);
            reader= readerBLL.GetReader(ID);
            if (reader == null)
            {
                MessageBox.Show("读者不存在！");
                return;
            }
            if (!reader.rdPwd.Equals(txtrdPwd.Text))
            {
                MessageBox.Show("读者号或读者密码错误！");
                return;
            }
                
            int type = reader.rdType;
            readertype = readertypeBLL.GetReaderType(type);
            SetReaderToText();
            DataBind1(ID);
        }

        //private void frmBorrowBook_Load(object sender, EventArgs e)//数据绑定
        //{
        //    DataBind1();
        //}

        private void DataBind1(int ID)
        {
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();

            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "select PunishRate from TB_ReaderType where rdType="+reader.rdType;
            //cmd.Parameters.AddWithValue("@rdID", ID);
            SqlDataReader sdr = cmd.ExecuteReader();
           
            float punishrate = 0;
            while (sdr.Read())
            {
               punishrate = Convert.ToSingle(sdr["PunishRate"]);
            }
            sdr.Close();

            SqlCommand cmd1 = conn.CreateCommand();
            cmd1.CommandText = "select BorrowID,IdDateRetPlan from TB_Borrow where rdID=" + ID;
            SqlDataReader sdr1 = cmd1.ExecuteReader();
            while (sdr1.Read())
            {
                int borrowid = Convert.ToInt32(sdr1["BorrowID"]);
                DateTime idateretplan = Convert.ToDateTime(sdr1["IdDateRetPlan"]);
                int day = (DateTime.Now - idateretplan).Days;
                float money;
                if (day > 0)
                {
                   money = day * punishrate;
                }else
                {
                    day = 0;
                    money = 0;
                }
                borrowBLL.Update(DateTime.Now,day, money,money,borrowid);
            }
            sdr1.Close();

            SqlDataAdapter sda = new SqlDataAdapter("select TB_Book.bkID 图书序号,bkName 图书名,bkAuthor 图书作者,IdContinueTimes 续借次数,IdDateOut 借出日期,IdDateRetPlan 预计归还日期,IdDateRetAct 实际归还日期,IdOverDay 超期天数,IdOverMoney 超期金额,IdPunishMoney 罚款金额 from TB_Book,TB_Borrow where TB_Book.bkID=TB_Borrow.bkID and rdID=" + ID, conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
        private void DataBind2()
        {
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlDataAdapter sda =new SqlDataAdapter("select bkID 图书序号,bkCode 图书编号,bkName 书名,bkAuthor 作者,bkPress 出版社,bkDatePress 出版日期,bkISBN ISBN,bkCatalog 分类号,bkPages 页数,bkPrice 价格,bkDateIn 入馆日期,bkStatus 状态 from TB_Book where bkID="+book.bkID,conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
        }
        private void  DataBind3(string name)
        {
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter();
            string sql = "select bkID 图书序号,bkCode 图书编号,bkName 书名,bkAuthor 作者,bkPress 出版社,bkDatePress 出版日期,bkISBN ISBN,bkCatalog 分类号,bkPages 页数,bkPrice 价格,bkDateIn 入馆日期,bkStatus 状态 from TB_Book where bkName like @name";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.Add(new SqlParameter() { ParameterName = "@name", SqlDbType = SqlDbType.VarChar, Value = name });
            sda.SelectCommand = cmd;
            DataTable table = new DataTable();
            sda.Fill(table);
            dataGridView2.DataSource = table;
        }

        private void button2_Click(object sender, EventArgs e)//图书序号查询
        {
            if (txtbkID.Text == "")
                return;
            for (int i = 0; i < txtbkID.Text.Length; i++)
            {
                if (!char.IsNumber(txtbkID.Text[i]))
                {
                    MessageBox.Show("图书序号为非法输入\n请输入数字！");
                    return;
                }
            }
            book.bkID = Convert.ToInt32(txtbkID.Text);
            DataBind2();

        }

        private void button3_Click(object sender, EventArgs e)//图书名查询
        {
            string name = txtbkName.Text;
            name = "%" + name + "%";
            DataBind3(name);
        }

        private void button4_Click(object sender, EventArgs e)//借书
        {

            reader = readerBLL.GetReader(Convert.ToInt32(txtrdID.Text));
            readertype = readertypeBLL.GetReaderType(Convert.ToInt32(txtrdType.Text));
            int rowindex = dataGridView2.CurrentCell.RowIndex;
            book = bookBLL.GetBook(Convert.ToInt32(dataGridView2[0, rowindex].Value));
            int flag=borrowBLL.BorrowBook(reader, readertype, book, OperatorUser);
            if (flag == 1)
            {
                MessageBox.Show("有值为空","提示");
            }else if (flag == 2)
            {
                MessageBox.Show("借书证无效","提示");
            }
            else if (flag == 5)
            {
                MessageBox.Show("借书数量已达上线，请归还图书后再借！","提示");
            }
            else if (flag == 3)
            {
                MessageBox.Show("图书不在馆","提示");
            }else if (flag == 4)
            {
                MessageBox.Show("借书成功","提示");
            }
        }

        private void button6_Click(object sender, EventArgs e)//续借
        {
            int rowindex = dataGridView1.CurrentCell.RowIndex;
            int rdid = Convert.ToInt32(txtrdID.Text);
            int bkid = Convert.ToInt32(dataGridView1[0, rowindex].Value);
            int rdtype = Convert.ToInt32(txtrdType.Text);
            DateTime iddateretplan = Convert.ToDateTime(dataGridView1[5, rowindex].Value);
            int times = Convert.ToInt32(dataGridView1[3, rowindex].Value);
            readertype = readertypeBLL.GetReaderType(rdtype);
            if (Convert.ToInt32(dataGridView1[7, rowindex].Value) > 0)
            {
                MessageBox.Show("该书已超期,不可续借");
                return;
            }
            if (Convert.ToInt32(dataGridView1[3, rowindex].Value) + 1 > readertype.CanContinueTimes)
            {
                MessageBox.Show("续借次数达到上限！", "提示");
                return;
            }
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "update TB_Borrow set IdDateRetPlan=@IdDatePlan,IdContinueTimes=@IdContinueTimes where rdID=@rdID and bkID=@bkID";
            cmd.Parameters.AddWithValue("@IdDatePlan", iddateretplan.AddDays(readertype.CanLendDay));
            cmd.Parameters.AddWithValue("@IdContinueTimes", times + 1);
            cmd.Parameters.AddWithValue("rdID", rdid);
            cmd.Parameters.AddWithValue("bkID", bkid);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("续借成功！");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("续借失败！");
            }
 
        }

        private void button7_Click(object sender, EventArgs e)//还书
        {
            int rowindex = dataGridView1.CurrentCell.RowIndex;
            int rdid =Convert.ToInt32(txtrdID.Text);
            int bkid = Convert.ToInt32(dataGridView1[0, rowindex].Value);
            book = bookBLL.GetBook(bkid);
            int day = Convert.ToInt32(dataGridView1[7, rowindex].Value);
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "delete from TB_Borrow where rdID=@rdID and bkID=@bkID";
            cmd.Parameters.AddWithValue("@rdID", rdid);
            cmd.Parameters.AddWithValue("@bkID",bkid);
            try
            {
                if (day > 0)
                {
                    MessageBox.Show("该借书已超期，请先\n交清罚款后再还书!", "提示");
                    return;
                }
                cmd.ExecuteNonQuery();
                book.bkStatus = "在馆";
                bookBLL.Update(book);
                MessageBox.Show("还书成功", "提示", MessageBoxButtons.OK);
            }
            catch (SqlException ex)
            {
                MessageBox.Show("还书失败！","提示",MessageBoxButtons.OK);
            }
            
            DataBind1(rdid);
        }
    }
}

﻿using BookManage.BLL;
using BookManage.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace BookManage
{
    public partial class frmAddBook : Form
    {
        private Book book=new Book();
        private BookAdmin bookBLL = new BookAdmin();
        private int number = 0;
        public frmAddBook()
        {
            InitializeComponent();
            txtSNum.Text = setBkID().ToString();
        }
        private static int setBkID()
        {
            /****************************************当图书为空时，还未解决*/
            int bkid = 0;
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "select max(bkID) from TB_Book ";
            //int count = cmd.ExecuteNonQuery();
            //MessageBox.Show("" + count);
            if (cmd.ExecuteNonQuery()>0) { 
                
            }
            bkid = Convert.ToInt32(cmd.ExecuteScalar());
            //MessageBox.Show("" + bkid);
            return bkid+1;
        }
        private void setTextToBook()
        {
            if (txtCode.Text == "" || txtName.Text == "" || txtAuthor.Text == "" || txtPress.Text == "" || cmbDatePress.Text == "" || txtISBN.Text == "" || cmbCatalog.Text == "" ||
                cmbLanguage.Text == "" || txtPages.Text == "" || txtPrice.Text == "" || cmbDateIn.Text == "" || txtNumber.Text == "") {
                MessageBox.Show("请完整填写书籍信息！");
                return;
            }

            book.bkID = Convert.ToInt32(txtSNum.Text);
            //book.bkID=setBkID();
            book.bkCode = txtCode.Text;
            book.bkName = txtName.Text;
            book.bkAuthor = txtAuthor.Text;
            book.bkPress = txtPress.Text;
            book.bkDatePress =Convert.ToDateTime(cmbDatePress.Text);
            book.bkISBN = txtISBN.Text;
            book.bkCatalog = cmbCatalog.Text;
            //book.bkLanguage =Convert.ToInt32(cmbLanguage.Text);
            if (cmbLanguage.Text=="中文")
            {
                book.bkLanguage = 0;
            }else if (cmbLanguage.Text == "英文")
            {
                book.bkLanguage = 1;
            }else if (cmbLanguage.Text == "日文")
            {
                book.bkLanguage = 2;
            }else if (cmbLanguage.Text == "俄文")
            {
                book.bkLanguage = 3;
            }else if (cmbLanguage.Text == "德文")
            {
                book.bkLanguage = 4;
            }else if (cmbLanguage.Text == "法文")
            {
                book.bkLanguage = 5;
            }
            for (int i = 0; i < txtPages.Text.Length; i++)
            {
                if (!char.IsNumber(txtPages.Text[i]))
                {
                    MessageBox.Show("页数为非法输入\n请输入数字！");
                    return;
                }
            }
            book.bkPages = Convert.ToInt32(txtPages.Text);
            book.bkPrice = Convert.ToSingle(txtPrice.Text);
            book.bkDateIn = Convert.ToDateTime(cmbDateIn.Text);
            for (int i = 0; i < txtNumber.Text.Length; i++)
            {
                if (!char.IsNumber(txtNumber.Text[i]))
                {
                    MessageBox.Show("图书数量为非法输入\n请输入数字！");
                    return;
                }
            }
            number = Convert.ToInt32(txtNumber.Text);
            book.bkBrief = richTextBoxBrief.Text;
            if (pictureBoxCover.Image == null) {
                book.bkCover = null;
            }else 
            {
                MemoryStream ms = new MemoryStream();
                pictureBoxCover.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
                book.bkCover = ms.GetBuffer();
            }
            book.bkStatus = "在馆";
        }

        private void buttonAdd_Click(object sender, EventArgs e)//添加
        {
            setTextToBook();
            for(int i = 0; i < number; i++)
            {
                book.bkID = book.bkID + i;
                try
                {
                    bookBLL.Add(book);
                    MessageBox.Show("添加成功！");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("添加失败！");
                }
            }
       
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonUpload_Click(object sender, EventArgs e)//上载图片
        {
            OpenFileDialog ofd1 = new OpenFileDialog();
            ofd1.Filter = "图片文件(*.jpg;*.bmp;*.png;*.gif)|*.jpg;*.bmp;*.png;*.gif";
            if (ofd1.ShowDialog() == DialogResult.OK)
            {
                Image imgPhoto = Image.FromFile(ofd1.FileName);
                pictureBoxCover.Image = imgPhoto;
            }
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((int)e.KeyChar < 48 || (int)e.KeyChar > 57) && (int)e.KeyChar != 8 && (int)e.KeyChar != 46)
                e.Handled = true;
            //小数点的处理。
            if ((int)e.KeyChar == 46)                           //小数点
            {
                if (txtPrice.Text.Length <= 0)
                    e.Handled = true;   //小数点不能在第一位
                else       
                {
                    float f;
                    float oldf;
                    bool b1 = false, b2 = false;
                    b1 = float.TryParse(txtPrice.Text, out oldf);
                    b2 = float.TryParse(txtPrice.Text + e.KeyChar.ToString(), out f);
                    if (b2 == false)
                    {
                        if (b1 == true)
                            e.Handled = true;
                        else
                            e.Handled = false;
                    }
                }
            }
        }
    }
}

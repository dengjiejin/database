﻿using BookManage.BLL;
using BookManage.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookManage
{
    public partial class frmReaderType : Form
    {
        private DataTable dt = null;
        
        private ReaderType readertype = new ReaderType();
        private ReaderTypeAdmin readertypeBLL = new ReaderTypeAdmin();
        public frmReaderType()
        {
            InitializeComponent();
            DataBind();
            readertype = readertypeBLL.GetReaderType(Convert.ToInt32(dataGridView1[0, 0].Value));
            //setReaderTypeToText();
        }
        private void setTextToReaderType()
        {
            readertype.rdType = Convert.ToInt32(txtType.Text);
            readertype.rdTypeName = txtTypeName.Text;
            readertype.CanLendQty = Convert.ToInt32(txtBorrowQty.Text);
            readertype.CanLendDay = Convert.ToInt32(txtDay.Text);
            readertype.CanContinueTimes = Convert.ToInt32(txtTimes.Text);
            readertype.PunishRate = Convert.ToSingle(txtRate.Text);
            readertype.DateValid = Convert.ToInt32(txtValidDay.Text);

        }
        private void setReaderTypeToText() {
            if (dataGridView1[0, dataGridView1.CurrentCell.RowIndex].Value.ToString() == "")
            {
                return;
            }
            if (readertype == null)
                return;
            txtType.Text = readertype.rdType.ToString();
            txtTypeName.Text = readertype.rdTypeName.ToString();
            txtBorrowQty.Text = readertype.CanLendQty.ToString();
            txtDay.Text = readertype.CanLendDay.ToString();
            txtTimes.Text = readertype.CanContinueTimes.ToString();
            txtRate.Text = readertype.PunishRate.ToString();
            txtValidDay.Text = readertype.DateValid.ToString();
        }

        private void frmReaderType_Load(object sender, EventArgs e)//绑定函数
        {
            DataBind();
        }

        private void DataBind()//数据绑定
        {
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select rdType 读者类型,rdTypeName 读者类型名称,CanLendQty 可借书数量,CanLendDay 可借书天数,CanContinueTimes 可续借次数,DateValid 证件有效期,PunishRate 罚款率 from TB_ReaderType", conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void toolStripButton8_Click(object sender, EventArgs e)//关闭
        {
            this.Close();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)//添加
        {
            /***********如何再添加之前将文本框中的值设为空**************/
            if (txtType.Text.Trim() == "" || txtTypeName.Text.Trim() == "" || txtBorrowQty.Text == "" || txtDay.Text == "" || txtRate.Text == "" || txtTimes.Text == "" || txtValidDay.Text == "")
            {
                MessageBox.Show("请先完整填写要添加的信息！", "提示", MessageBoxButtons.OK);
                return;
            }
            setTextToReaderType();
            readertypeBLL.Add(readertype);
            DataBind();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)//首记录
        {
            dataGridView1.CurrentCell = dataGridView1[0, 0];
        }

        private void toolStripButton2_Click(object sender, EventArgs e)//下记录
        {
            int row = dataGridView1.CurrentRow.Index;
            if (row < dataGridView1.RowCount - 2)
            {
                dataGridView1.CurrentCell = dataGridView1[0, row + 1];
            }
            else
            {
                dataGridView1.CurrentCell = dataGridView1[0, 0];
            }
                
        }

        private void toolStripButton3_Click(object sender, EventArgs e)//上记录
        {
            int row = dataGridView1.CurrentRow.Index;
            if (row > 0)
            {
                dataGridView1.CurrentCell = dataGridView1[0, row - 1];
            }
            else
            {
                dataGridView1.CurrentCell = dataGridView1[0, dataGridView1.RowCount - 2];
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)//尾记录
        {
            dataGridView1.CurrentCell = dataGridView1[0, dataGridView1.RowCount - 2];
        }

        private void toolStripButton7_Click(object sender, EventArgs e)//删除
        {
            DialogResult dr = MessageBox.Show("是否确认删除！", "提示", MessageBoxButtons.YesNo);
            if (dr == DialogResult.No)
                return;
           
            int rowindex = dataGridView1.CurrentCell.RowIndex;
            //MessageBox.Show("" + dataGridView1[rowindex, 5] + "");
            //MessageBox.Show(dataGridView1[0, rowindex].Value + "");
            //MessageBox.Show("" + rowindex);
            readertype.rdType = Convert.ToInt32(dataGridView1[0, rowindex].Value);
            //readertype.rdTypeName = dataGridView1[1, rowindex].Value.ToString();
            //readertype.CanLendQty = Convert.ToInt32(dataGridView1[2, rowindex].Value);
            //readertype.CanLendDay = Convert.ToInt32(dataGridView1[3, rowindex].Value);
            //readertype.CanContinueTimes = Convert.ToInt32(dataGridView1[4, rowindex].Value);
            //readertype.DateValid = Convert.ToInt32(dataGridView1[5, rowindex].Value);
            //readertype.PunishRate = (float)Convert.ToDouble(dataGridView1[6, rowindex].Value);
            readertypeBLL.Delete(readertype);
            DataBind();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)//修改
        {
            //txtType.Enabled = false;
            int rowindex = dataGridView1.CurrentCell.RowIndex;
            readertype = readertypeBLL.GetReaderType(Convert.ToInt32(dataGridView1[0, rowindex].Value));
            setTextToReaderType();
            try
            {
                readertypeBLL.Update(readertype);
                MessageBox.Show("修改成功！");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("修改失败！");
            }
            DataBind();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            /****点击标题栏未解决****/
            if (dataGridView1[0, dataGridView1.CurrentCell.RowIndex].Value.ToString() == "")
                return;
            if (dataGridView1[0, dataGridView1.CurrentCell.RowIndex].Value == null)
                return;
            readertype = readertypeBLL.GetReaderType(Convert.ToInt32(dataGridView1[0, dataGridView1.CurrentCell.RowIndex].Value));
            setReaderTypeToText();
        }
    }
}

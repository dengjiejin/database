﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BookManage.BLL;
using BookManage.Model;


namespace BookManage
{
    public partial class frmLogin : Form
    {
        private int loginTimes = 0;
        private ReaderAdmin readerBLL = new ReaderAdmin();
        public static Reader reader = null;
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            loginTimes++;

            int rdID;
            for (int i = 0; i < textUserID.Text.Length; i++)
            {
                if (!char.IsNumber(textUserID.Text[i]))
                {
                    MessageBox.Show("用户名为非法输入\n请输入数字！");
                    return;
                }
            }
            rdID = Convert.ToInt32(textUserID.Text.Trim());
            reader = readerBLL.GetReader(rdID);


            if (reader == null)
            {
                textUserID.Focus();
                lblReaderInfo.Text = "登录信息：查无此人..{" + loginTimes.ToString() + "}";
            }
            else
            {
                if (reader.rdPwd == textUserPwd.Text)
                {
                    //readertype=readerBLL.GetReaderType(reader.rdType);
                    if (reader.rdStatus == "有效")
                    {
                        this.DialogResult = DialogResult.OK;//登陆成功
                    }else
                    {
                        lblReaderInfo.Text = "登陆信息：借书证无效..{" + loginTimes.ToString() + "}";
                    }
                    
                }
                else
                {
                    textUserPwd.Text = "";
                    textUserPwd.Focus();
                    lblReaderInfo.Text = "登陆信息：..密码错误！{" + loginTimes.ToString() + "}";
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

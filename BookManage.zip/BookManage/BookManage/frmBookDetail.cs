﻿using BookManage.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using BookManage.BLL;

namespace BookManage
{
    public partial class frmBookDetail : Form
    {
        Book book = frmBook.book;
        private string status;
        private BookAdmin BookBLL = new BookAdmin();
        private int flag = frmBook.flag;
        public frmBookDetail()
        {
           
            
            InitializeComponent();
            setDatabseToText();
            if (flag == 1)
            {
                groupBox1.Enabled = false;
                button2.Enabled = false;
            }
        }
        private void setTextToBook()
        {
            book.bkID=Convert.ToInt32(txtbkID.Text);
            book.bkCode = txtbkCode.Text;
            book.bkName = txtbkName.Text;
            book.bkPress = txtbkPress.Text;
            book.bkDatePress = Convert.ToDateTime(cmbPressDate.Text);
            book.bkISBN = txtISBN.Text;
            //book.bkLanguage = Convert.ToInt32(cmbbkLanguage.Text);
            if (cmbbkCataloge.Text == "中文")
            {
                book.bkLanguage = 0;
            }else if (cmbbkLanguage.Text=="英文")
            {
                book.bkLanguage = 1;
            }else if (cmbbkLanguage.Text == "日文")
            {
                book.bkLanguage = 2;
            }else if (cmbbkLanguage.Text == "俄文")
            {
                book.bkLanguage = 3;
            }else if (cmbbkLanguage.Text == "德文")
            {
                book.bkLanguage = 4;
            }else if (cmbbkLanguage.Text == "法文")
            {
                book.bkLanguage = 5;
            }
            book.bkPages = Convert.ToInt32(txtbkPages.Text);
            book.bkPrice = Convert.ToSingle(txtbkPrice.Text);
            book.bkCatalog = cmbbkCataloge.Text;
            book.bkBrief= richTextBoxBrief.Text;
            book.bkDateIn = Convert.ToDateTime(cmbDataIn.Text);
            book.bkAuthor = txtbkAuther.Text;
            if (pictureBoxCover.Image != null)
            {
                MemoryStream ms = new MemoryStream();
                pictureBoxCover.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
                book.bkCover = ms.GetBuffer();
            }
            book.bkStatus = status;
        }

        private void button2_Click(object sender, EventArgs e)//保存
        {
            setTextToBook();
            try
            {
                BookBLL.Update(book);
                MessageBox.Show("修改成功！");

            }
            catch (SqlException ex)
            {
                MessageBox.Show("修改失败！");
            }
        }

        private void setDatabseToText()
        {
            ////SqlDataAdapter DA = new SqlDataAdapter();
            ////String FindSQL = "select fname as 姓名,femployeecode as 学号 from dbo.T_B_Employee where fname = @aaa ";
            ////SqlCommand theCommand = new SqlCommand(FindSQL, conn);
            ////theCommand.Parameters.Add(new SqlParameter() { ParameterName = "@aaa", SqlDbType = SqlDbType.VarChar, Size = 20, Value = "张三" });
            ////DA.SelectCommand = theCommand;
            ////DataTable Date_Table = new DataTable();
            ////DA.Fill(Date_Table);
            if (book.bkID.ToString() == null) { 
                txtbkID.Text = "";
            }
            else { 
                txtbkID.Text = book.bkID.ToString();
            }
            if (book.bkID.ToString() == null) {
                txtbkID.Text = "";
            }
            else
            {
                txtbkCode.Text = book.bkCode.ToString();
            }
            if (book.bkName.ToString() == null)
            {
                txtbkName.Text = "";
            }else
            {
                txtbkName.Text = book.bkName.ToString();
            }
            if (book.bkAuthor.ToString()==null)
            {
                txtbkAuther.Text = "";
            }else
            {
                txtbkAuther.Text = book.bkAuthor.ToString();
            }
            if (book.bkPress.ToString()==null)
            {
                txtbkPress.Text = "";
            }else
            {
                txtbkPress.Text = book.bkPress.ToString();
            }
            if (book.bkDatePress.ToString()==null)
            {
                cmbPressDate.Text = "";
            }else
            {
                cmbPressDate.Text = book.bkDatePress.ToString();
            }
            if (book.bkISBN.ToString()==null)
            {
                txtISBN.Text = "";
            }else
            {
                txtISBN.Text = book.bkISBN.ToString();
            }
            if (book.bkCatalog.ToString() == null)
            {
                cmbbkCataloge.Text = "";
            }
            else
            {
                cmbbkCataloge.Text = book.bkCatalog.ToString();
            }

            //cmbbkLanguage.Text = book.bkLanguage.ToString();
            if (book.bkLanguage == 0)
            {
                cmbbkLanguage.Text = "中文";
            }else if (book.bkLanguage == 1)
            {
                cmbbkLanguage.Text = "英文";
            }else if (book.bkLanguage == 2)
            {
                cmbbkLanguage.Text = "日文";
            }else if (book.bkLanguage == 3)
            {
                cmbbkLanguage.Text = "俄文";
            }else if (book.bkLanguage == 4)
            {
                cmbbkLanguage.Text = "德文";
            }else if (book.bkLanguage == 5)
            {
                cmbbkLanguage.Text = "法文";
            }
            
            if (book.bkPages.ToString()==null)
            {
                txtbkPages.Text = "";
            }
            else
            {
                txtbkPages.Text = book.bkPages.ToString();

            }
            if (book.bkPrice.ToString()==null)
            {
                txtbkPrice.Text = "";
            }else
            {
                txtbkPrice.Text = book.bkPrice.ToString();
            }
            if (book.bkDateIn.ToString()==null)
            {
                cmbDataIn.Text = "";
            }
            else
            {
                cmbDataIn.Text = book.bkDateIn.ToString();
            }
            if (book.bkBrief.ToString()==null)
            {
                richTextBoxBrief.Text = "";
            }else
            {
                richTextBoxBrief.Text = book.bkBrief.ToString();
            }

            //pictureBoxCover.Image=table.Rows[0][13]
            if (book.bkCover ==null )
                pictureBoxCover.Image = null;
            else
            {
                    MemoryStream ms = new MemoryStream(book.bkCover);
                    Image imgPhoto = Bitmap.FromStream(ms, true);
                    pictureBoxCover.Image = imgPhoto;
            }
            status = book.bkStatus.ToString();
        }

        private void button1_Click(object sender, EventArgs e)//上载图片
        {
            OpenFileDialog ofd1 = new OpenFileDialog();
            ofd1.Filter = "图片文件(*.jpg;*.bmp;*.png;*.gif)|*.jpg;*.bmp;*.png;*.gif";
            if (ofd1.ShowDialog() == DialogResult.OK)
            {
                Image imgPhoto = Image.FromFile(ofd1.FileName);
                pictureBoxCover.Image = imgPhoto;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

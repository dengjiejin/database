﻿using BookManage.BLL;
using BookManage.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookManage
{
    public partial class frmUpdatePwd : Form
    {
        private ReaderAdmin readerBLL = new ReaderAdmin();
        private Reader reader = new Reader();
        public frmUpdatePwd()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//修改密码
        {
            //Reader reader = frmLogin.reader;
            for (int i = 0; i < txtrdID.Text.Length; i++)
            {
                if (!char.IsNumber(txtrdID.Text[i]))
                {
                    MessageBox.Show("借书证号为非法输入\n请输入数字！");
                    return;
                }
            }
            reader.rdID = Convert.ToInt32(txtrdID.Text);
            if (txtold.Text == "" || txtnew1.Text == "" || txtnew2.Text == "")
            {
                MessageBox.Show("不能有空！");
                frmUpdatePwd frmupdate = new frmUpdatePwd();
            }
            //else if (!txtold.Text.Equals(reader.rdPwd)) {
            //    MessageBox.Show("原密码错误");
            //    frmUpdatePwd frmupdate = new frmUpdatePwd();

            //}
            else if (!txtnew1.Text.Equals(txtnew2.Text))
            {
                MessageBox.Show("两次密码输入不一样！");
                frmUpdatePwd frmupdate = new frmUpdatePwd();
            }
            else {
               
                reader.rdPwd = txtnew1.Text;
                //MessageBox.Show("" + reader.rdID + reader.rdName + reader.rdPhone+reader.rdPwd+" " +reader.rdSex);
                //readerBLL.Update(reader);
                string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
                SqlConnection conn = new SqlConnection(strConn);
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = "update TB_Reader set rdPwd=@rdPwd where rdID=@rdID";
                cmd.Parameters.AddWithValue("@rdPwd", txtnew1.Text);
                cmd.Parameters.AddWithValue("@rdID", reader.rdID);
                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("密码修改成功！");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("修改失败！");
                }
                //cmd.ExecuteNonQuery();
                //MessageBox.Show("密码修改成功！");
                this.Close();
            }

        }

        private void button2_Click(object sender, EventArgs e)//退出
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)//重置密码
        {
            for (int i = 0; i < txtrdID.Text.Length; i++)
            {
                if (!char.IsNumber(txtrdID.Text[i]))
                {
                    MessageBox.Show("借书证号非法输入\n请输入数字！");
                    return;
                }
            }
            reader.rdID = Convert.ToInt32(txtrdID.Text);
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();

            cmd.CommandText = "update TB_Reader set rdPwd=@rdPwd where rdID=@rdID";
            cmd.Parameters.AddWithValue("@rdPwd", 123);
            cmd.Parameters.AddWithValue("@rdID", reader.rdID);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("重置密码为123！");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("重置失败！");
            }
            
        }
    }
}

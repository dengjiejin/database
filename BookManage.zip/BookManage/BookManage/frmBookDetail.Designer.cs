﻿namespace BookManage
{
    partial class frmBookDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtbkID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbkCode = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtbkName = new System.Windows.Forms.TextBox();
            this.txtbkAuther = new System.Windows.Forms.TextBox();
            this.txtbkPress = new System.Windows.Forms.TextBox();
            this.txtISBN = new System.Windows.Forms.TextBox();
            this.cmbbkCataloge = new System.Windows.Forms.ComboBox();
            this.cmbbkLanguage = new System.Windows.Forms.ComboBox();
            this.txtbkPages = new System.Windows.Forms.TextBox();
            this.txtbkPrice = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBoxCover = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.richTextBoxBrief = new System.Windows.Forms.RichTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.cmbPressDate = new System.Windows.Forms.DateTimePicker();
            this.cmbDataIn = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCover)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "图书序号";
            // 
            // txtbkID
            // 
            this.txtbkID.Location = new System.Drawing.Point(109, 15);
            this.txtbkID.Name = "txtbkID";
            this.txtbkID.ReadOnly = true;
            this.txtbkID.Size = new System.Drawing.Size(121, 25);
            this.txtbkID.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "图书编号";
            // 
            // txtbkCode
            // 
            this.txtbkCode.Location = new System.Drawing.Point(109, 65);
            this.txtbkCode.Name = "txtbkCode";
            this.txtbkCode.Size = new System.Drawing.Size(121, 25);
            this.txtbkCode.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "图书名称";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "图书作者";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 188);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "出版社名";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 227);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 15);
            this.label6.TabIndex = 7;
            this.label6.Text = "出版日期";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 267);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 15);
            this.label7.TabIndex = 8;
            this.label7.Text = "标准ISBN";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 299);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 15);
            this.label8.TabIndex = 9;
            this.label8.Text = "分类名称";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(20, 339);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 15);
            this.label9.TabIndex = 10;
            this.label9.Text = "所属语种";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 379);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 15);
            this.label10.TabIndex = 11;
            this.label10.Text = "图书页数";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(20, 417);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 15);
            this.label11.TabIndex = 12;
            this.label11.Text = "图书价格";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(20, 452);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 15);
            this.label12.TabIndex = 13;
            this.label12.Text = "入馆日期";
            // 
            // txtbkName
            // 
            this.txtbkName.Location = new System.Drawing.Point(109, 109);
            this.txtbkName.Name = "txtbkName";
            this.txtbkName.Size = new System.Drawing.Size(121, 25);
            this.txtbkName.TabIndex = 14;
            // 
            // txtbkAuther
            // 
            this.txtbkAuther.Location = new System.Drawing.Point(109, 152);
            this.txtbkAuther.Name = "txtbkAuther";
            this.txtbkAuther.Size = new System.Drawing.Size(121, 25);
            this.txtbkAuther.TabIndex = 15;
            // 
            // txtbkPress
            // 
            this.txtbkPress.Location = new System.Drawing.Point(109, 188);
            this.txtbkPress.Name = "txtbkPress";
            this.txtbkPress.Size = new System.Drawing.Size(121, 25);
            this.txtbkPress.TabIndex = 16;
            // 
            // txtISBN
            // 
            this.txtISBN.Location = new System.Drawing.Point(109, 264);
            this.txtISBN.Name = "txtISBN";
            this.txtISBN.Size = new System.Drawing.Size(121, 25);
            this.txtISBN.TabIndex = 18;
            // 
            // cmbbkCataloge
            // 
            this.cmbbkCataloge.FormattingEnabled = true;
            this.cmbbkCataloge.Location = new System.Drawing.Point(109, 299);
            this.cmbbkCataloge.Name = "cmbbkCataloge";
            this.cmbbkCataloge.Size = new System.Drawing.Size(121, 23);
            this.cmbbkCataloge.TabIndex = 19;
            // 
            // cmbbkLanguage
            // 
            this.cmbbkLanguage.FormattingEnabled = true;
            this.cmbbkLanguage.Location = new System.Drawing.Point(109, 339);
            this.cmbbkLanguage.Name = "cmbbkLanguage";
            this.cmbbkLanguage.Size = new System.Drawing.Size(121, 23);
            this.cmbbkLanguage.TabIndex = 20;
            // 
            // txtbkPages
            // 
            this.txtbkPages.Location = new System.Drawing.Point(109, 379);
            this.txtbkPages.Name = "txtbkPages";
            this.txtbkPages.Size = new System.Drawing.Size(121, 25);
            this.txtbkPages.TabIndex = 21;
            // 
            // txtbkPrice
            // 
            this.txtbkPrice.Location = new System.Drawing.Point(109, 417);
            this.txtbkPrice.Name = "txtbkPrice";
            this.txtbkPrice.Size = new System.Drawing.Size(121, 25);
            this.txtbkPrice.TabIndex = 22;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbDataIn);
            this.groupBox1.Controls.Add(this.cmbPressDate);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.pictureBoxCover);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.richTextBoxBrief);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtbkPrice);
            this.groupBox1.Controls.Add(this.txtbkPages);
            this.groupBox1.Controls.Add(this.cmbbkLanguage);
            this.groupBox1.Controls.Add(this.cmbbkCataloge);
            this.groupBox1.Controls.Add(this.txtISBN);
            this.groupBox1.Controls.Add(this.txtbkPress);
            this.groupBox1.Controls.Add(this.txtbkAuther);
            this.groupBox1.Controls.Add(this.txtbkName);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtbkCode);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtbkID);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(9, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(896, 499);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(789, 470);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 28;
            this.button1.Text = "上载图片";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBoxCover
            // 
            this.pictureBoxCover.Location = new System.Drawing.Point(609, 66);
            this.pictureBoxCover.Name = "pictureBoxCover";
            this.pictureBoxCover.Size = new System.Drawing.Size(272, 394);
            this.pictureBoxCover.TabIndex = 27;
            this.pictureBoxCover.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(612, 36);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 15);
            this.label14.TabIndex = 26;
            this.label14.Text = "图片封面";
            // 
            // richTextBoxBrief
            // 
            this.richTextBoxBrief.Location = new System.Drawing.Point(278, 59);
            this.richTextBoxBrief.Name = "richTextBoxBrief";
            this.richTextBoxBrief.Size = new System.Drawing.Size(287, 408);
            this.richTextBoxBrief.TabIndex = 25;
            this.richTextBoxBrief.Text = "";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(285, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 15);
            this.label13.TabIndex = 24;
            this.label13.Text = "内容简介";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(282, 536);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 25;
            this.button2.Text = "保存";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(432, 536);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 26;
            this.button3.Text = "返回";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // cmbPressDate
            // 
            this.cmbPressDate.Location = new System.Drawing.Point(109, 227);
            this.cmbPressDate.Name = "cmbPressDate";
            this.cmbPressDate.Size = new System.Drawing.Size(121, 25);
            this.cmbPressDate.TabIndex = 29;
            // 
            // cmbDataIn
            // 
            this.cmbDataIn.Location = new System.Drawing.Point(109, 452);
            this.cmbDataIn.Name = "cmbDataIn";
            this.cmbDataIn.Size = new System.Drawing.Size(121, 25);
            this.cmbDataIn.TabIndex = 30;
            // 
            // frmBookDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(961, 582);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmBookDetail";
            this.Text = "图书明细";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCover)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbkID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbkCode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtbkName;
        private System.Windows.Forms.TextBox txtbkAuther;
        private System.Windows.Forms.TextBox txtbkPress;
        private System.Windows.Forms.TextBox txtISBN;
        private System.Windows.Forms.ComboBox cmbbkCataloge;
        private System.Windows.Forms.ComboBox cmbbkLanguage;
        private System.Windows.Forms.TextBox txtbkPages;
        private System.Windows.Forms.TextBox txtbkPrice;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBoxCover;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RichTextBox richTextBoxBrief;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DateTimePicker cmbPressDate;
        private System.Windows.Forms.DateTimePicker cmbDataIn;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookManage.Model;
using BookManage.DAL;
using System.Data;

namespace BookManage.BLL
{
    public class ReaderAdmin
    {
        public ReaderAdmin() { }
        public DataTable GetReader(int rdType,string rdDept,string rdName) {
            return (DAL.ReaderDAL.GetReader(rdType,rdDept,rdName));
        }
        public Reader GetReader(int rdID)
        {
            return (DAL.ReaderDAL.GetObjectDRByID(rdID));
        }
        public DataTable GetAllReaderType()
        {
            return (ReaderTypeDAL.GetAll());
        }
        public int Add(Reader reader)
        {
            return (DAL.ReaderDAL.Add(reader));
        }
        public int Update(Reader reader)
        {
            return (DAL.ReaderDAL.Update(reader));
        }
        public int Delete(Reader reader)
        {
            return (DAL.ReaderDAL.Delete(reader));
        }
    }
}

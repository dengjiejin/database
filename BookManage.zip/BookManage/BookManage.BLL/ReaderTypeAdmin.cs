﻿using BookManage.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.BLL
{
    public class ReaderTypeAdmin
    {
        public ReaderType GetReaderType(int rdType)
        {
            return (DAL.ReaderTypeDAL.GetObjectbyID(rdType));
        }
        public int Add(ReaderType readertype)
        {
            return (DAL.ReaderTypeDAL.Add(readertype));
        }
        public int Update(ReaderType readertype)
        {
            return (DAL.ReaderTypeDAL.Update(readertype));
        }
        public int Delete(ReaderType readertype)
        {
            return (DAL.ReaderTypeDAL.Delete(readertype));
        }
    }
}

﻿using BookManage.DAL;
using BookManage.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.BLL
{
    
    public class BorrowAdmin
    {
        private static int SetBorrowID(int rdid)
        {
            /*********如何设置当某为读者未借书时的借书序号*/
            int borrowid = 0;
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "select max(BorrowID) from TB_Borrow";/*********************/
            cmd.Parameters.AddWithValue("@rdID", rdid);
            if (cmd.ExecuteScalar() == null) {
                borrowid = 0;
            }
            else
            {
                borrowid = Convert.ToInt32(cmd.ExecuteScalar());
            }
            return borrowid + 1;
        }
        public int Update(Borrow borrow)
        {
            return (DAL.BorrowDAL.Upadte(borrow));
        }
        public int Update(DateTime IdDateRetAct,int IdOverDay, float IdOverMoney, float IdPunishMoney, int borrow)
        {
            return (DAL.BorrowDAL.Update(IdDateRetAct,IdOverDay, IdOverMoney, IdPunishMoney, borrow));
        }
        public Borrow GetBorrow(int BorrowID)
        {
            return (DAL.BorrowDAL.GetObjectDRByID(BorrowID));
        }

        public int BorrowBook(Reader reader,ReaderType readerType,Book book,Reader OperatorUser)
        {
            if (reader == null || readerType == null || book == null || OperatorUser == null)
                return 1;
            if (reader.rdStatus != "有效")
                return 2;
            if ((readerType.CanLendQty - reader.rdBorrowQty) <= 0) {
                return 5;
            }
            if (book.bkStatus != "在馆")
                return 3;

            reader.rdBorrowQty++;
            try
            {
                ReaderDAL.Update(reader);
            }
            catch (SqlException ex)
            {

            }

            book.bkStatus = "借出";
            BookDAL.Update(book);

            Borrow borrow = new Borrow();
            //SetBorrowID(reader.rdID);
            borrow.BorrowID = SetBorrowID(reader.rdID);
            borrow.rdID = reader.rdID;
            borrow.bkID = book.bkID;
            borrow.IdContinueTimes = 0;
            borrow.IdDateOut = DateTime.Now;
            borrow.IdDateRetPlan = borrow.IdDateOut.AddDays(readerType.CanLendDay);
            borrow.IdDateRetAct = DateTime.Now;
            borrow.IsHasReturn = false;
            borrow.OperatorLend = OperatorUser.rdName;
            BorrowDAL.Add(borrow);
            return 4;
        }
        public int ContinueBorrow()
        {
            return 0;
        }
    }
}

﻿using BookManage.DAL;
using BookManage.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.BLL
{
    public class BookAdmin
    {
        public Book GetBook(int bkID)
        {
            return (DAL.BookDAL.GetObjectDRByID(bkID));
        }
        public int Add(Book book)
        {
            return (DAL.BookDAL.Add(book));
        } 
        public int Update(Book book)
        {
            return (DAL.BookDAL.Update(book));
        }
        public int Delete(Book book)
        {
            return (DAL.BookDAL.Delete(book));
        }
        public DataTable GetBookPlus(int bkID,string bkCode,string bkName,string bkAuthor,string bkPress/*,DateTime bkPressDate,DateTime bkDateIn*/)
        {
            return (DAL.BookDAL.GetBookPlus(bkID, bkCode, bkName, bkAuthor, bkPress/*, bkPressDate, bkDateIn*/));
        }
        public bool BorrowBook(Reader reader,ReaderType readertype,Book book,Reader OperatorUser)
        {
            if (reader == null || readertype == null || book == null || OperatorUser==null)
                return false;
            if (reader.rdStatus != "有效" || (readertype.CanLendQty - reader.rdBorrowQty) <= 0)
                return false;
            if (book.bkStatus != "在馆") return false;

            reader.rdBorrowQty++;
            BookDAL.Update(book);

            Borrow borrow = new Borrow();
            borrow.rdID = reader.rdID;
            borrow.bkID = book.bkID;
            borrow.IdContinueTimes = 0;
            borrow.IdDateOut = DateTime.Now;
            borrow.IdDateRetPlan = DateTime.Now.AddDays(readertype.CanLendDay);
            borrow.IsHasReturn = false;
            borrow.OperatorLend = OperatorUser.rdName;
            BorrowDAL.Add(borrow);
            return true;

        }
    }
}

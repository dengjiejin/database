﻿using BookManage.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.DAL
{
    public class BorrowDAL
    {
        public static int Add(Borrow borrow)
        {
            int rows = 0;
            string sql = "insert into TB_Borrow(BorrowID,rdID,bkID,IdContinueTimes,IdDateOut,IdDateRetPlan,IdDateRetAct,IdOverDay,IdOverMoney,IdPunishMoney,IsHashReturn,OperatorLend,OperatorRet) Values(@BorrowID,@rdID,@bkID,@IdContinueTimes,@IdDateOut,@IdDateRetPlan,@IdDateRetAct,@IdOverDay,@IdOverMoney,@IdPunishMoney,@IsHashReturn,@OperatorLend,@OperatorRet)";
            SqlParameter[] parameters =
            {
                new SqlParameter("@borrowID",borrow.BorrowID),
                new SqlParameter("@rdID", borrow.rdID),
                new SqlParameter("@bkID", borrow.bkID),
                new SqlParameter("@IdContinueTimes", borrow.IdContinueTimes),
                new SqlParameter("@IdDateOut", SqlDbType.DateTime) { SqlValue=borrow.IdDateOut},
                new SqlParameter("@IdDateRetPlan", SqlDbType.DateTime) { SqlValue=borrow.IdDateRetPlan},
                new SqlParameter("@IdDateRetAct", SqlDbType.DateTime) { SqlValue=borrow.IdDateRetAct},
                new SqlParameter("@IdOverDay", borrow.IdOverDay),
                new SqlParameter("@IdOverMoney", borrow.IdOverMoney),
                new SqlParameter("@IdPunishMoney", borrow.IdPunishMoney),
                new SqlParameter("@IsHashReturn", borrow.IsHasReturn),
                new SqlParameter("@OperatorLend", borrow.OperatorLend),
                new SqlParameter("@OperatorRet", borrow.OperatorRet)
            };
            foreach (SqlParameter parameter in parameters)
            {

                if (parameter.Value == null)
                {
                    parameter.Value = DBNull.Value;
                }
            }
            try
            {
                rows = SqlHelper.ExecuteNonQuery(sql, parameters);
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            return rows;
        }
        public static int Update( DateTime IdDateRetAct,int IdOverDay, float IdOverMoney, float IdPunishMoney, int borrow)
        {
            int rows = 0;
            string sql = "update TB_Borrow set IdDateRetAct=@IdDateRetAct,IdOverDay=@IdOverDay,IdOverMoney=@IdOverMoney,IdPunishMoney=@IdPunishMoney where BorrowID=@BorrowID";
            SqlParameter[] parameters =
            {
                new SqlParameter("@IdDateRetAct",IdDateRetAct),
                new SqlParameter("@IdOverDay",IdOverDay),
                new SqlParameter("@IdOverMoney",IdOverMoney),
                new SqlParameter("@IdPunishMoney",IdPunishMoney),
                new SqlParameter("@BorrowID",borrow)
            };
            try
            {
                rows = SqlHelper.ExecuteNonQuery(sql, parameters);
            }catch(SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            return rows;
        }
        public static int Upadte(Borrow borrow)
        {
            int rows = 0;
            string sql = "update TB_Borrow set"
                        + "BorrowID=@BorrowID"
                        + "rdID=@rdID"
                        + "bkID=@bkID"
                        + "IdContinueTimes=@IdContinueTimes"
                        + "IdDateOut=@IdDateOut"
                        + "IdDateRetPlan=@rdPhone"
                        + "IdDateRetAct=@IdDateRetAct"
                        + "IdOverDay=@IdOverDay"
                        + "IdOverMoney=@IdOverMoney"
                        + "IdPunishMoney=@IdPunishMoney"
                        + "IsHasReturn=@IsHasReturn"
                        + "OperatorLend=@OperatorLend"
                        + "OperatorRet=@OperatorRet";
            SqlParameter[] parameters =
              {
                new SqlParameter("@BorrowID",borrow.BorrowID),
                new SqlParameter("@rdID", borrow.rdID),
                new SqlParameter("@bkID", borrow.bkID),
                new SqlParameter("@IdContinueTimes", borrow.IdContinueTimes),
                new SqlParameter("@IdDateOut", borrow.IdDateOut),
                new SqlParameter("@IdDateRetPlan", borrow.IdDateRetPlan),
                new SqlParameter("@IdDateRetAct", borrow.IdDateRetAct),
                new SqlParameter("@IdOverDay", borrow.IdOverDay),
                new SqlParameter("@IdOverMoney", borrow.IdOverMoney),
                new SqlParameter("@IdPunishMoney", borrow.IdPunishMoney),
                new SqlParameter("@IsHasReturn", borrow.IsHasReturn),
                new SqlParameter("@OperatorLend", borrow.OperatorLend),
                new SqlParameter("@OperatorRet", borrow.OperatorRet),
            };
            try
            {
                rows = SqlHelper.ExecuteNonQuery(sql, parameters);
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);

            }
            return rows;
        }
        public static int Delete(Borrow borrow)
        {
            int rows = 0;
            string sql = "delete from TB_Borrow where BorrowID=@BorrowID";
            SqlParameter[] parameters = { new SqlParameter("@BorrowID", borrow.BorrowID) };
            try
            {
                rows = SqlHelper.ExecuteNonQuery(sql, parameters);
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            return rows;
        }
        public static DataRow GetDRByID(int BorrowID)
        {
            string sql = "select *from TB_Borrow where BorrowID=@BorrowID";
            SqlParameter[] parameters = { new SqlParameter("@BorrowID", BorrowID) };
            DataTable dt = null;
            dt = SqlHelper.GetDataTable(sql, parameters, "TB_Borrow");
            DataRow dr = null;
            if (dt == null || dt.Rows.Count == 0)
            {
                return dr;
            }
            else
            {
                dr = dt.Rows[0];
                return dr;
            }
        }
        public static Borrow GetObjectDRByID(int BorrowID)
        {
            DataRow dr = GetDRByID(BorrowID);
            return SqlHelper.DataRowToT<Borrow>(dr);
        }
    }
}

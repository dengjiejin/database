﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Collections;
using System.Data;
using System.Reflection;
using BookManage.Model;

namespace BookManage.DAL
{
    public class SqlHelper
    {
        private static string _strConnection = @"Data Source=DESKTOP-SBP8470;
        Initial Catalog = Library;User ID=djj;Password=djj545143694;";
        private static SqlConnection conn = new SqlConnection(_strConnection);
        private static void OpenConn() {
            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
            }
            catch
            {
                throw new Exception("MS SQL Server数据库连接失败！");
            }
        }
        private static void CloseConn() {
                if (conn != null)
                {
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
        }
        public static int ExecuteNonQuery(string sql,SqlParameter[] parameters) {
            int rows = 0;
            try {
                OpenConn();
                SqlCommand cmd = new SqlCommand(sql,conn);
                if (parameters != null)
                {
                    foreach(SqlParameter parameter in parameters)
                    {
                        cmd.Parameters.Add(parameter);
                    }
                }
                rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
              throw new Exception(ex.Message);

            }
            finally


            {
                CloseConn();
            }
            return rows;
        }
        public static object ExecuteScalar(string sql) {
            object obj = null;
            try
            {
                OpenConn();
                SqlCommand cmd = new SqlCommand(sql, conn);
                obj = cmd.ExecuteScalar();
            }
            catch(SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                CloseConn();
            }
            return obj;
        }
        public static  DataTable GetDataTable(string sql, SqlParameter[] parameters,string TableName) {
            DataTable dt = null;
            try { 
            OpenConn();
            SqlCommand cmd = new SqlCommand(sql, conn);
            if (parameters != null)
            {
                foreach(SqlParameter parameter in parameters)
                {
                    cmd.Parameters.Add(parameter);
                }
            }
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds, TableName);
            dt = ds.Tables[0];
            }catch(SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                CloseConn();
            }
            return dt;
        }
        public static SqlDataReader GetDataReader(string sql)
        {
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlcom = new SqlCommand(sql, conn);
                OpenConn();
                dr = sqlcom.ExecuteReader();
            }catch(SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                CloseConn();
            }
            return dr;
        }
        public static int ExecuteStoredProc(string storedProcName,SqlParameter[] parameters)
        {
            int rows = 0;
            try
            {
                OpenConn();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = storedProcName;
                cmd.Connection = conn;

                if (parameters != null)
                {
                    foreach(SqlParameter parameter in parameters)
                    {
                        cmd.Parameters.Add(parameter);
                    }
                }
                rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                CloseConn();
            }
            return rows;
        }
        public static DataTable ExecuteStoredProc(string storedPrecName,SqlParameter[] parameters,string TableName)
        {
            DataTable dt = null;
            try
            {
                OpenConn();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = storedPrecName;
                cmd.Connection = conn;

                if (parameters!=null) {
                    foreach (SqlParameter parameter in parameters)
                    {
                        cmd.Parameters.Add(parameter);
                    }
                }
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sda.Fill(ds, TableName);
                dt = ds.Tables[0];
            }
            catch (SqlException ex){
                throw new Exception(ex.Message);
            }
            finally
            {
                CloseConn();
            }
            return dt;
        }
        public static List<T> DataTableToT<T>(DataTable source) where T : class, new()
        {
            List<T> itemlist = null;
            if (source == null || source.Rows.Count == 0)
            {
                return itemlist;
            }
            itemlist = new List<T>();
            T item = null;
            Type targettype = typeof(T);
            Type ptype = null;
            Object value = null;
            foreach(DataRow dr in source.Rows)
            {
                item = new T();
                foreach(PropertyInfo pi in targettype.GetProperties())
                {
                    if(pi.CanWrite && source.Columns.Contains(pi.Name))
                    {
                        ptype = Type.GetType(pi.PropertyType.FullName);
                        value = Convert.ChangeType(dr[pi.Name], ptype);
                        pi.SetValue(item, value, null);
                    }
                }
                itemlist.Add(item);
            }
            return itemlist;
        }
        public static T DataRowToT<T>(DataRow source) where T : class, new()
        {
            T item = null;
            if (source == null)
            {
                return item;
            }
            item = new T();
            Type targettype = typeof(T);
            Type ptype = null;
            Object value = null;

            foreach (PropertyInfo pi in targettype.GetProperties())
            {
                if (pi.CanWrite && source.Table.Columns.Contains(pi.Name))
                {
                    if (!(pi.PropertyType.FullName == "System.Byte[]" && source[pi.Name] == DBNull.Value))
                    {
                        //if (!(pi.PropertyType.FullName == "System.Byte[]"))
                        //{
                        //    if (!(source[pi.Name] == DBNull.Value))
                        //    {
                        ptype = Type.GetType(pi.PropertyType.FullName);
                                value = Convert.ChangeType(source[pi.Name], ptype);
                                pi.SetValue(item, value, null);
                        //    }
                        //}

                    }
                }
            }
            return item;
        }
    }
}

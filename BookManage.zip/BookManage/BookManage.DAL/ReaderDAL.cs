﻿using BookManage.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookManage.DAL;

namespace BookManage.DAL
{
    public class ReaderDAL
    {
        public static int Add(Reader reader)
        {
            int rows = 0;
            string sql = "insert into TB_Reader(rdID,rdName,rdSex,rdType,rdDept,rdPhone,rdEmail,rdDateReg,rdPhoto,rdStatus,rdBorrowQty,rdPwd,rdAdminRoles)"
                + "values(@rdID,@rdName,@rdSex,@rdType,@rdDept,@rdPhone,@rdEmail,@rdDateReg,@rdPhoto,@rdStatus,@rdBorrowQty,@rdPwd,@rdAdminRoles)";
            SqlParameter[] parameters =
            {
                new SqlParameter("@rdID",reader.rdID),
                new SqlParameter("@rdName", reader.rdName),
                new SqlParameter("@rdSex", reader.rdSex),
                new SqlParameter("@rdType", reader.rdType),
                new SqlParameter("@rdDept", reader.rdDept),
                new SqlParameter("@rdPhone", reader.rdPhone),
                new SqlParameter("@rdEmail", reader.rdEmail),
                new SqlParameter("@rdDateReg", reader.rdDateReg),
                new SqlParameter("@rdPhoto", /*reader.rdPhoto*/SqlDbType.Image) {SqlValue=reader.rdPhoto},
                new SqlParameter("@rdStatus", reader.rdStatus),
                new SqlParameter("@rdBorrowQty", reader.rdBorrowQty),
                new SqlParameter("@rdPwd", reader.rdPwd),
                new SqlParameter("@rdAdminRoles", reader.rdAdminRoles),
            };
            foreach (SqlParameter parameter in parameters)
            {
                
                if (parameter.Value == null)
                {
                    parameter.Value = DBNull.Value;
                }
            }
            try
            {
                rows = SqlHelper.ExecuteNonQuery(sql, parameters);
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            return rows;
        }
        public static int Update(Reader reader)
        {
            int rows = 0;
            //string sql = "update TB_Reader set"
            //            //+ "rdID=@rdID,"
            //            + "rdName=@rdName,"
            //            + "rdSex=@rdSex,"
            //            + "rdType=@rdType,"
            //            + "rdDept=@rdDept,"
            //            + "rdPhone=@rdPhone,"
            //            + "rdEmail=@rdEmail,"
            //            + "rdDateReg=@rdDateReg,"
            //            + "rdPhoto=@rdPhoto,"
            //            + "rdStstus=@rdStatus,"
            //            + "rdBorrowQty=@rdBorrowQty,"
            //            + "rdPwd=@rdPwd,"
            //            + "rdAdminRoles=@rdAdminRoles";
            //rdID = @rdID,
            string sql = "update TB_Reader set rdName=@rdName,rdSex=@rdSex,rdType=@rdType,rdDept=@rdDept,rdPhone=@rdPhone,rdEmail=@rdEmail,rdDateReg=@rdDateReg,rdPhoto=@rdPhoto,rdStatus=@rdStatus,rdBorrowQty=@rdBorrowQty,rdPwd=@rdPwd,rdAdminRoles=@rdAdminRoles where rdID=@rdID";
            SqlParameter[] parameters =
      {
                new SqlParameter("@rdID",reader.rdID),
                new SqlParameter("@rdName", reader.rdName),
                new SqlParameter("@rdSex", reader.rdSex),
                new SqlParameter("@rdType", reader.rdType),
                new SqlParameter("@rdDept", reader.rdDept),
                new SqlParameter("@rdPhone", reader.rdPhone),
                new SqlParameter("@rdEmail", reader.rdEmail),
                new SqlParameter("@rdDateReg", reader.rdDateReg),
                new SqlParameter("@rdPhoto", SqlDbType.Image){SqlValue=reader.rdPhoto},
                new SqlParameter("@rdStatus", reader.rdStatus),
                new SqlParameter("@rdBorrowQty", reader.rdBorrowQty),
                new SqlParameter("@rdPwd", reader.rdPwd),
                new SqlParameter("@rdAdminRoles", reader.rdAdminRoles),
            };
            foreach (SqlParameter parameter in parameters)
            {

                if (parameter.Value == null)
                {
                    parameter.Value = DBNull.Value;
                }
            }
                try
                {
                    rows = SqlHelper.ExecuteNonQuery(sql, parameters);
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);

                }
                return rows;
            
        }
        public static int Delete(Reader reader)
        {
            int rows = 0;
            string sql = "delete from TB_Reader where rdID=@rdID";
            SqlParameter[] parameters = { new SqlParameter("@rdID", reader.rdID) };
            try
            {
                rows = SqlHelper.ExecuteNonQuery(sql, parameters);
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            return rows;
        }
        public static DataRow GetDRByID(int rdID)
        {
            string sql = "select * from TB_Reader where rdID=@rdID";
            SqlParameter[] parameters = { new SqlParameter("@rdID", rdID) };
            DataTable dt = null;
            dt = SqlHelper.GetDataTable(sql, parameters, "TB_Reader");
            DataRow dr = null;
            if (dt == null || dt.Rows.Count == 0)
            {
                return dr;
            }
            else
            {
                dr = dt.Rows[0];
                return dr;
            }
        }
        public static Reader GetObjectDRByID(int rdID)
        {
            DataRow dr = GetDRByID(rdID);
            return SqlHelper.DataRowToT<Reader>(dr);
        }
        public static DataTable GetReader(int rdType,string rdDept,string rdName)
        {
            string sql;
            if (rdType <= 0 && rdDept == "" && rdName=="")
            {
                sql = "select *from TB_Reader where 0=1";
                return SqlHelper.GetDataTable(sql, null, "TB_Reader");
            }
            rdDept = (rdDept == "") ? ("%") : ("%" + rdDept + "%");
            rdName = (rdName == "") ? ("%") : ("%" + rdName + "%");
            if (rdType <= 0)
            {
                sql = "select *from TB_Reader where rdDept like @rdDept and rdName like @rdName";
                SqlParameter[] parameters =
                {
                    new SqlParameter("@rdDept",rdDept),
                    new SqlParameter("@rdName",rdName)
                };
                return SqlHelper.GetDataTable(sql, parameters, "TB_Reader");
            }
            else
            {
                sql = "select *from TB_Reader where rdType=@rdType and rdDept like @rdDept and rdName like @rdName";
                SqlParameter[] parameters =
                {
                    new SqlParameter("@rdType",rdType),
                    new SqlParameter("@rdDept",rdDept),
                    new SqlParameter("@rdName",rdName)
                };
                return SqlHelper.GetDataTable(sql, parameters, "TB_Reader");
            }
        }
    }
}

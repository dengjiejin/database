﻿using BookManage.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.DAL
{
    public class BookDAL
    {
        public static int Add(Book book)
        {
            int rows = 0;
            string sql = "insert into TB_Book(bkID,bkCode,bkName,bkAuthor,bkPress,bkDatePress,bkISBN,bkCatalog,bkLanguage,bkPages,bkPrice,bkDateIn,bkBrief,bkCover,bkStatus)"
                + "values(@bkID,@bkCode,@bkName,@bkAuthor,@bkPress,@bkDatePress,@bkISBN,@bkCatalog,@bkLanguage,@bkPages,@bkPrice,@bkDateIn,@bkBrief,@bkCover,@bkStatus)";
            SqlParameter[] parameters = {
                new SqlParameter("@bkID",book.bkID),
                new SqlParameter("@bkCode",book.bkCode),
                new SqlParameter("@bkName",book.bkName),
                new SqlParameter("@bkAuthor",book.bkAuthor),
                new SqlParameter("@bkPress",book.bkPress),
                new SqlParameter("@bkDatePress",book.bkDatePress),
                new SqlParameter("@bkISBN",book.bkISBN),
                new SqlParameter("@bkCatalog",book.bkCatalog),
                new SqlParameter("@bklanguage",book.bkLanguage),
                new SqlParameter("@bkPages",book.bkPages),
                new SqlParameter("@bkPrice",book.bkPrice),
                new SqlParameter("@bkDateIn",book.bkDateIn),
                new SqlParameter("@bkBrief",book.bkBrief),
                new SqlParameter("@bkCover",/*book.bkCover*/SqlDbType.Image) { SqlValue=book.bkCover},
                new SqlParameter("@bkStatus",book.bkStatus)
            };
            foreach (SqlParameter parameter in parameters)
            {

                if (parameter.Value == null)
                {
                    parameter.Value = DBNull.Value;
                }
            }
            try
            {
                rows = SqlHelper.ExecuteNonQuery(sql, parameters);
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            return rows;
        }
        public static int Delete(Book book)
        {
            int rows = 0;
            string sql = "delete from TB_book where bkID=@bkID";
            SqlParameter[] parameters = { new SqlParameter("@bkID", book.bkID) };
            try
            {
                rows = SqlHelper.ExecuteNonQuery(sql, parameters);
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            return rows;
        }
        public static int Update(Book book)
        {
            int rows = 0;
            //string sql = "update TB_Book set"
            //            //+"bkID=@bkID,"
            //            + "bkCode=@bkCode"
            //            + "bkName=@bkName"
            //            + "bkAuthor=@bkAuthor"
            //            + "bkPress=@bkPress"
            //            + "bkDatePress=@bkDatePress"
            //            + "bkISBN=@bkISBN"
            //            + "bkCatalog=@bkCatalog"
            //            + "bklanguage=@bklanguage"
            //            + "bkPages=@bkPages"
            //            + "bkPrice=@bkPrice"
            //            + "bkDateIn=@bkDateIn"
            //            + "bkBrief=@bkBrief"
            //            + "bkCover=@bkCover"
            //            + "bkSataus=@bkSataus"
            //            + "where bkID=@bkID";
            string sql="update TB_Book set bkCode=@bkCode,bkName=@bkName,bkAuthor=@bkAuthor,bkPress=@bkPress,bkDatePress=@bkDatePress,bkISBN=@bkISBN,bkCatalog=@bkCatalog,bkLanguage=@bkLanguage,bkPages=@bkPages,bkPrice=@bkPrice,bkDateIn=@bkDateIn,bkBrief=@bkBrief,bkCover=@bkCover,bkStatus=@bkStatus where bkID=@bkID";
            SqlParameter[] parameters = {
                new SqlParameter("@bkID",book.bkID),
                new SqlParameter("@bkCode",book.bkCode),
                new SqlParameter("@bkName",book.bkName),
                new SqlParameter("@bkAuthor",book.bkAuthor),
                new SqlParameter("@bkPress",book.bkPress),
                new SqlParameter("@bkDatePress",SqlDbType.DateTime) { SqlValue=book.bkDatePress},
                new SqlParameter("@bkISBN",book.bkISBN),
                new SqlParameter("@bkCatalog",book.bkCatalog),
                new SqlParameter("@bklanguage",book.bkLanguage),
                new SqlParameter("@bkPages",book.bkPages),
                new SqlParameter("@bkPrice",book.bkPrice),
                new SqlParameter("@bkDateIn",SqlDbType.DateTime) {SqlValue=book.bkDateIn },
                new SqlParameter("@bkBrief",book.bkBrief),
                new SqlParameter("@bkCover",SqlDbType.Image) { SqlValue=book.bkCover},
                new SqlParameter("@bkStatus",book.bkStatus),
            };
            foreach (SqlParameter parameter in parameters)
            {

                if (parameter.Value == null)
                {
                    parameter.Value = DBNull.Value;
                }
            }
            try
            {
                rows = SqlHelper.ExecuteNonQuery(sql, parameters);
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);

            }
            return rows;
        }
        public static DataRow GetDRByID(int bkID)
        {
            string sql = "select *from TB_Book where bkID=@bkID";
            SqlParameter[] parameters = { new SqlParameter("@bkID", bkID) };
            DataTable dt = null;
            dt = SqlHelper.GetDataTable(sql, parameters, "TB_Book");
            DataRow dr = null;
            if (dt == null || dt.Rows.Count == 0)
            {
                return dr;
            }
            else
            {
                dr = dt.Rows[0];
                return dr;
            }
        }
        public static Book GetObjectDRByID(int bkID)
        {
            DataRow dr = GetDRByID(bkID);
            return SqlHelper.DataRowToT<Book>(dr);
        }
        public static DataTable GetBookPlus(int bkID,string bkCode,string bkName,string bkAuthor,string bkPress/*,DateTime bkPressDate,DateTime bkDateIn*/)
        {
            string strConn = "server=.;database=Library;user id=djj;pwd=djj545143694";
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            if (bkID <= 0)
            {
                bkCode =(bkCode == "") ? "%" : "%" + bkCode + "%";
                bkName = (bkName == "") ? "%" : "%" + bkName + "%";
                bkAuthor = (bkAuthor == "") ? "%" : "%" + bkAuthor + "%";
                bkPress = (bkPress == "") ? "%" : "%" + bkPress + "%";
               
                SqlDataAdapter sda = new SqlDataAdapter();
                string str = "select bkID,bkCode,bkName,bkAuthor,bkPress,bkDatePress,bkISBN,bkCatalog,bkLanguage,bkPages,bkPrice,bkDateIn,bkStatus from TB_Book where bkCode like @bkCode and bkName like @bkName and bkAuthor like @bkAuthor and bkPress like @bkPress";
                SqlCommand cmd = new SqlCommand(str, conn);
                cmd.Parameters.Add(new SqlParameter() { ParameterName = "@bkCode", SqlDbType = SqlDbType.VarChar,Value = bkCode });
                cmd.Parameters.Add(new SqlParameter() { ParameterName = "@bkName", SqlDbType = SqlDbType.VarChar, Value = bkName });
                cmd.Parameters.Add(new SqlParameter() { ParameterName = "@bkAuthor", SqlDbType = SqlDbType.VarChar, Value = bkAuthor });
                cmd.Parameters.Add(new SqlParameter() { ParameterName = "@bkPress", SqlDbType = SqlDbType.VarChar, Value = bkPress });
                sda.SelectCommand = cmd;
                DataTable table = new DataTable();
                sda.Fill(table);
                return table;
            }
            else
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                string str = "select * from TB_Book where bkID=@bkID";
                SqlCommand cmd = new SqlCommand(str, conn);
                cmd.Parameters.Add(new SqlParameter() { ParameterName = "@bkID", SqlDbType = SqlDbType.Int, Value = bkID });
                sda.SelectCommand = cmd;
                DataTable table = new DataTable();
                sda.Fill(table);
                return table;
            }
        }
    }
}

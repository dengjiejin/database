﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.Model
{
    public class Reader
    {
        public Reader() { }
        private int _rdID;
        private string _rdName;
        private string _rdSex;
        private int _rdType;
        private string _rdDept;
        private string _rdPhone;
        private string _rdEmail;
        private DateTime _rdDateReg;
        private Byte[] _rdPhoto;
        private string _rdStatus;
        private int _rdBorrowQty;
        private string _rdPwd;
        private int _rdAdminRoles;

        public int rdID {
            get { return _rdID; }
            set { _rdID = value; }
        }
        public string rdName {
            get { return _rdName; }
            set { _rdName = value; }
        }
        public string rdSex {
            get { return _rdSex; }
            set { _rdSex = value; }
        }
        public int rdType {
            get { return _rdType; }
            set { _rdType = value; }
        }
        public string rdDept {
            get { return _rdDept; }
            set { _rdDept = value; }
        }
        public string rdPhone {
            get { return _rdPhone; }
            set { _rdPhone = value; }
        }
        public string rdEmail
        {
            get { return _rdEmail; }
            set { _rdEmail = value; }
        }
        public DateTime rdDateReg
        {
            get { return _rdDateReg; }
            set { _rdDateReg = value; }
        }
        public Byte[] rdPhoto {
            get { return _rdPhoto; }
            set { _rdPhoto = value; }
        }
        public int rdBorrowQty {
            get { return _rdBorrowQty; }
            set { _rdBorrowQty = value; }
        }
        public string rdPwd
        {
            get { return _rdPwd; }
            set { _rdPwd = value; }
        }
        public int rdAdminRoles {
            get { return _rdAdminRoles; }
            set { _rdAdminRoles = value; }
        }
        public string rdStatus
        {
            get { return _rdStatus; }
            set { _rdStatus = value; }
        }
        public Reader(Reader rd) {
            this._rdID = rd._rdID;
            this._rdName = rd._rdName;
            this._rdSex = rd._rdSex;
            this._rdType = rd._rdType;
            this._rdDept = rd._rdDept;
            this._rdPhone = rd._rdPhone;
            this._rdEmail = rd._rdEmail;
            this._rdDateReg = rd._rdDateReg;
            this._rdPhoto = rd._rdPhoto;
            this._rdStatus = rd._rdStatus;
            this._rdBorrowQty = rd._rdBorrowQty;
            this._rdPwd = rd._rdPwd;
            this._rdAdminRoles = rd._rdAdminRoles;
        }

        public static string ColumnTitle(string columnName) {
            string[,] ColumnsTitle =
            {
                { "rdID","借书证号"},{"rdName", "姓名"}
                , {"rdSex","性别" }, {"rdType","读者类别" }
                , {"rdDept","单位" }, {"rdPhone","电话" }
                , {"rdEmail","邮箱" }, {"rdDateReg","办证日期" }
                , {"rdPhoto","照片" }, {"rdStatus","证件状态" }
                , {"rdBorrowQty","已借书" },{"rdPwd","密码" }
                , {"rdAdminRoles","管理员角色" }
            };
            for(int i = 0; i < ColumnsTitle.Length / 2; i++)
            {
                if (columnName == ColumnsTitle[i, 0])
                    return ColumnsTitle[i, 1];
            }
            return columnName;
        }
        public bool IsReaderAdmin() {
            return ((rdAdminRoles & 1) > 0);
        }
        public bool IsBookAdmin() {
            return ((rdAdminRoles & 2) > 0);
        }
        public bool IsBorrowAdmin()
        {
            return ((rdAdminRoles & 4) > 0);
        }
        public bool IsSystemAdmin()
        {
            return ((rdAdminRoles & 8) > 0);
        }
    }
}

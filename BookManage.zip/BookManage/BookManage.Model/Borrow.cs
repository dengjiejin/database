﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.Model
{
    public class Borrow
    {
        public Borrow() { }
        private long _BorrowID;
        private int _rdID;
        private int _bkID;
        private int _IdContinueTimes;
        private DateTime _IdDateOut;
        private DateTime _IdDateRetPlan;
        private DateTime _IdDateRetAct;
        private int _IdOverDay;
        private float _IdOverMoney;
        private float _IdPunishMoney;
        private bool _IsHasReturn;
        private string _OperatorLend;
        private string _OperatorRet;

        public long BorrowID
        {
            get { return _BorrowID; }
            set { _BorrowID = value; }
        }
        public int rdID
        {
            get { return _rdID; }
            set { _rdID = value; }
        }
        public int bkID
        {
            get { return _bkID; }
            set { _bkID = value; }
        }
        public int IdContinueTimes
        {
            get { return _IdContinueTimes; }
            set { _IdContinueTimes = value; }
        }
        public DateTime IdDateOut
        {
            get { return _IdDateOut; }
            set { _IdDateOut = value; }
        }
        public DateTime IdDateRetPlan
        {
            get { return _IdDateRetPlan; }
            set { _IdDateRetPlan = value; }
        }
        public DateTime IdDateRetAct
        {
            get { return _IdDateRetAct; }
            set { _IdDateRetAct = value; }
        }
        public int IdOverDay
        {
            get { return _IdOverDay; }
            set { _IdOverDay = value; }
        }
        public float IdOverMoney
        {
            get { return _IdOverMoney; }
            set { _IdOverMoney = value; }
        }
        public float IdPunishMoney
        {
            get { return _IdPunishMoney; }
            set { _IdPunishMoney = value; }
        }
        public bool IsHasReturn
        {
            get { return _IsHasReturn; }
            set { _IsHasReturn = value; }
        }
        public string OperatorLend
        {
            get { return _OperatorLend; }
            set { _OperatorLend = value; }
        }
        public string OperatorRet
        {
            get { return _OperatorRet; }
            set { _OperatorRet = value; }
        }
        public Borrow(Borrow br)
        {
            this._BorrowID = br._BorrowID;
            this._rdID = br._rdID;
            this._bkID = br._bkID;
            this._IdContinueTimes = br._IdContinueTimes;
            this._IdDateOut = br._IdDateOut;
            this._IdDateRetAct = br._IdDateRetAct;
            this._IdDateRetPlan = br._IdDateRetPlan;
            this._IdOverDay = br._IdOverDay;
            this._IdOverMoney = br._IdOverMoney;
            this._IdPunishMoney = br._IdPunishMoney;
            this._IsHasReturn = br._IsHasReturn;
            this._OperatorLend = br._OperatorLend;
            this._OperatorRet = br._OperatorRet;
        }
    }
}

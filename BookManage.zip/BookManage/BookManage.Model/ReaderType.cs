﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.Model
{
    public class ReaderType
    { 
        public ReaderType() { }
        //私有字段
        private int _rdType;
        private string _rdTypeName;
        private int _CanLendQty;
        private int _CanLendDay;
        private int _CanContinueTimes;
        private float _PunishRate;
        private int _DateValid;

        //共有属性
        public int rdType {
            get { return _rdType; }
            set { _rdType = value; }
        }
        public String rdTypeName {
            get { return _rdTypeName; }
            set { _rdTypeName = value; }
        }
        public int CanLendQty {
            get { return _CanLendQty; }
            set { _CanLendQty = value; }
        }
        public int CanLendDay {
            get { return _CanLendDay; }
            set { _CanLendDay = value; }
        }
        public int CanContinueTimes {
            get { return _CanContinueTimes; }
            set { _CanContinueTimes = value; }
        }
        public int DateValid{
            get { return _DateValid; }
            set { _DateValid = value; }
        }
        public float PunishRate {
            get { return _PunishRate; }
            set { _PunishRate = value; }
        }
        public ReaderType(ReaderType rt)
        {
            this.rdType = rt.rdType;
            this.rdTypeName = rt.rdTypeName;
            this.CanLendQty = rt.CanLendQty;
            this.CanLendDay = rt.CanLendDay;
            this.CanContinueTimes = rt.CanContinueTimes;
            this.PunishRate = rt.PunishRate;
            this.DateValid = rt.DateValid;
        }

    }

}

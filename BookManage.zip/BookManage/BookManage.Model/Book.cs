﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.Model
{
    public class Book
    {
        public Book() { }
        private int _bkID;
        private string _bkCode;
        private string _bkName;
        private string _bkAuthor;
        private string _bkPress;
        private DateTime _bkDatePress;
        private string _bkISBN;
        private string _bkCatalog;
        private int _bkLanguage;
        private int _bkPages;
        private float _bkPrice;
        private DateTime _bkDateIn;
        private string _bkBrief;
        private byte[] _bkCover;
        private string _bkStatus;

        public int bkID
        {
            get { return _bkID; }
            set { _bkID = value; }
        }
        public string bkCode
        {
            get { return _bkCode; }
            set { _bkCode = value; }
        }
        public string bkName
        {
            get { return _bkName; }
            set { _bkName = value; }
        }
        public string bkAuthor
        {
            get { return _bkAuthor; }
            set { _bkAuthor = value; }
        }
        public string bkPress
        {
            get { return _bkPress; }
            set { _bkPress = value; }
        }
        public DateTime bkDatePress
        {
            get { return _bkDatePress; }
            set { _bkDatePress = value; }
        }
        public string bkISBN
        {
            get { return _bkISBN; }
            set { _bkISBN = value; }
        }
        public string bkCatalog
        {
            get { return _bkCatalog; }
            set { _bkCatalog = value; }
        }
        public int bkLanguage
        {
            get { return _bkLanguage; }
            set { _bkLanguage = value; }
        }
        public int bkPages
        {
            get { return _bkPages; }
            set { _bkPages = value; }
        }
        public float bkPrice
        {
            get { return _bkPrice; }
            set { _bkPrice = value; }
        }
        public DateTime bkDateIn
        {
            get { return _bkDateIn; }
            set { _bkDateIn = value; }
        }
        public string bkBrief
        {
            get { return _bkBrief; }
            set { _bkBrief = value; }
        }
        public Byte[] bkCover
        {
            get { return _bkCover; }
            set { _bkCover = value; }
        }
        public string bkStatus
        {
            get { return _bkStatus; }
            set { _bkStatus = value; }
        }
        public Book(Book bk) {
            this._bkID = bk._bkID;
            this._bkName = bk._bkName;
            this._bkCode = bk._bkCode;
            this._bkAuthor = bk._bkAuthor;
            this._bkPress = bk._bkPress;
            this._bkDatePress = bk._bkDatePress;
            this._bkISBN = bk._bkISBN;
            this._bkCatalog = bk._bkCatalog;
            this._bkLanguage = bk._bkLanguage;
            this._bkPages = bk._bkPages;
            this._bkPress = bk._bkPress;
            this._bkDateIn = bk._bkDateIn;
            this._bkBrief = bk._bkBrief;
            this._bkCover = bk._bkCover;
            this._bkStatus = bk._bkStatus;
        }
        public static string ColumnTitle(string columnName)
        {
            string[,] ColumnsTitle =
            {
                { "bkID","图书序号"},{"bkCode", "图书编号"}
                , {"bkName","图书名" }, {"bkAuthor","图书作者" }
                , {"bkPress","出版社名" }, {"bkDatePress","出版日期" }
                , {"bkISBN","ISBN" }, {"bkCatalog","图书类别" }
                , {"bkLanguage","语言" }, {"bkPages","页数" }
                , {"bkPrice","价格" },{"bkDateIn","入馆日期" }
                , {"bkStatus","图书状态" }
            };
            for (int i = 0; i < ColumnsTitle.Length / 2; i++)
            {
                if (columnName == ColumnsTitle[i, 0])
                    return ColumnsTitle[i, 1];
            }
            return columnName;
        }
    }
}
